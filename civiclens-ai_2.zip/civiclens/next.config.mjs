/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: { ignoreDuringBuilds: true },
  typescript: { ignoreBuildErrors: false },
  images: { unoptimized: true },
  // React Strict Mode intentionally double-mounts components in development
  // to surface missing effect cleanup. react-leaflet's MapContainer doesn't
  // tear down its underlying Leaflet instance cleanly across that double
  // mount, which throws "Map container is already initialized." This only
  // affects `next dev`'s diagnostics — production builds (`next build` /
  // `next start`) never double-invoke effects regardless of this setting.
  reactStrictMode: false,
};
export default nextConfig;
