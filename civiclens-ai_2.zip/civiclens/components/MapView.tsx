"use client";

import { useEffect, useRef, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "./leaflet-custom.css";
import "leaflet.heat";
import Link from "next/link";
import { CATEGORY_META, SEVERITY_META, timeAgo } from "@/lib/utils";
import type { Report } from "@/types";
import { LocateFixed, Flame } from "lucide-react";

// Leaflet's default marker icons reference bundler-unfriendly paths — build
// our own lightweight divIcon markers instead, colored by severity.
function makeIcon(report: Report) {
  const color = SEVERITY_META[report.severity].color === "#FFFFFF" ? "#E5484D" : SEVERITY_META[report.severity].bg;
  const ring = report.severity === "critical" ? "#E5484D" : report.severity === "high" ? "#EF8286" : "#0F7A72";
  const dot = report.severity === "critical" ? "#E5484D" : report.severity === "high" ? "#E5484D" : report.severity === "medium" ? "#F2A93B" : "#0F7A72";
  return L.divIcon({
    className: "",
    html: `<div style="width:16px;height:16px;border-radius:999px;background:${dot};border:2.5px solid white;box-shadow:0 1px 4px rgba(18,24,31,0.35)"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
    popupAnchor: [0, -8],
  });
}

function ClickHandler({ onClick }: { onClick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onClick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

function LocateButton() {
  const map = useMap();
  return (
    <button
      onClick={() => {
        map.locate({ setView: true, maxZoom: 15 });
      }}
      className="absolute bottom-6 right-3 z-[500] flex h-9 w-9 items-center justify-center rounded-full bg-surface border border-border shadow-card hover:border-teal-300 transition-colors"
      title="Use my location"
      type="button"
    >
      <LocateFixed size={16} className="text-ink-soft" />
    </button>
  );
}

function HeatLayer({ points, show }: { points: [number, number, number][]; show: boolean }) {
  const map = useMap();
  const layerRef = useRef<any>(null);

  useEffect(() => {
    if (show) {
      // @ts-ignore leaflet.heat augments L at runtime
      layerRef.current = L.heatLayer(points, { radius: 28, blur: 22, maxZoom: 16, gradient: { 0.3: "#0F7A72", 0.6: "#F2A93B", 1: "#E5484D" } });
      layerRef.current.addTo(map);
    }
    return () => {
      if (layerRef.current) map.removeLayer(layerRef.current);
    };
  }, [show, points, map]);

  return null;
}

export default function MapView({
  reports,
  onMapClick,
  center,
}: {
  reports: Report[];
  onMapClick?: (lat: number, lng: number) => void;
  center: [number, number];
}) {
  const [showHeat, setShowHeat] = useState(false);
  // A fresh, unique key per component instance guarantees React creates a
  // brand-new DOM node for the map container on every mount, rather than
  // potentially reusing one that Leaflet already attached itself to. This
  // is what actually makes "Map container is already initialized" /
  // "...is being reused by another instance" impossible, regardless of
  // what triggers the remount (Strict Mode, Fast Refresh, route changes).
  const [instanceKey] = useState(() => `map-${Math.random().toString(36).slice(2)}`);
  const heatPoints: [number, number, number][] = reports.map((r) => [
    r.lat,
    r.lng,
    r.severity === "critical" ? 1 : r.severity === "high" ? 0.75 : r.severity === "medium" ? 0.5 : 0.25,
  ]);

  return (
    <div className="relative h-full w-full">
      <MapContainer key={instanceKey} center={center} zoom={13} className="h-full w-full" zoomControl={true}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {onMapClick && <ClickHandler onClick={onMapClick} />}
        <LocateButton />
        <HeatLayer points={heatPoints} show={showHeat} />
        {!showHeat &&
          reports.map((r) => (
            <Marker key={r.id} position={[r.lat, r.lng]} icon={makeIcon(r)}>
              <Popup>
                <div className="w-52">
                  <p className="text-[11px] font-mono uppercase tracking-wide text-ink-faint mb-0.5">
                    {CATEGORY_META[r.category].label}
                  </p>
                  <p className="text-[13px] font-semibold text-ink leading-snug mb-1">{r.title}</p>
                  <p className="text-[11px] text-ink-faint mb-2">{timeAgo(r.createdAt)} · {r.votes} votes</p>
                  <Link href={`/issue/${r.id}`} className="text-[12px] font-medium text-teal-600 hover:underline">
                    View details →
                  </Link>
                </div>
              </Popup>
            </Marker>
          ))}
      </MapContainer>

      <button
        onClick={() => setShowHeat((v) => !v)}
        className={`absolute top-3 right-3 z-[500] flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] font-medium shadow-card transition-colors ${
          showHeat ? "bg-amber-300 border-amber-300 text-ink" : "bg-surface border-border text-ink-soft hover:border-teal-300"
        }`}
        type="button"
      >
        <Flame size={13} />
        {showHeat ? "Heatmap on" : "Heatmap"}
      </button>

      {onMapClick && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[500] rounded-full bg-ink/90 backdrop-blur px-3.5 py-1.5 text-[11.5px] font-medium text-white shadow-pop pointer-events-none">
          Tap anywhere on the map to report an issue
        </div>
      )}
    </div>
  );
}
