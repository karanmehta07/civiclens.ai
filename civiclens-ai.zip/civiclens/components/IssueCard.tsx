import Link from "next/link";
import { CATEGORY_META, timeAgo } from "@/lib/utils";
import CategoryIcon from "@/components/CategoryIcon";
import { SeverityBadge, PriorityPill } from "@/components/Badges";
import { ArrowUp, MessageSquare } from "lucide-react";
import type { Report } from "@/types";

export default function IssueCard({ report, dense = false }: { report: Report; dense?: boolean }) {
  const meta = CATEGORY_META[report.category];
  return (
    <Link
      href={`/issue/${report.id}`}
      className="group block rounded-md border border-border bg-surface p-3.5 transition-all hover:border-teal-300 hover:shadow-card"
    >
      <div className="flex items-start gap-3">
        {report.imageUrl ? (
          <img
            src={report.imageUrl}
            alt=""
            className="h-14 w-14 shrink-0 rounded-sm object-cover border border-line"
          />
        ) : (
          <div
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-sm border border-line"
            style={{ backgroundColor: `${meta.color}12` }}
          >
            <CategoryIcon category={report.category} size={20} className="opacity-70" />
          </div>
        )}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 mb-1">
            <CategoryIcon category={report.category} size={12} className="text-ink-faint shrink-0" />
            <span className="text-[11px] font-mono uppercase tracking-wide text-ink-faint truncate">
              {meta.label}
            </span>
          </div>
          <h3 className="text-[13.5px] font-medium text-ink leading-snug truncate group-hover:text-teal-700">
            {report.title}
          </h3>
          {!dense && (
            <p className="text-[12px] text-ink-muted mt-0.5 line-clamp-1">{report.address || "Location pinned on map"}</p>
          )}
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            <SeverityBadge severity={report.severity} />
            <PriorityPill score={report.priorityScore} />
            <span className="flex items-center gap-0.5 text-[11px] text-ink-faint">
              <ArrowUp size={11} /> {report.votes}
            </span>
            <span className="text-[11px] text-ink-faint">·</span>
            <span className="text-[11px] text-ink-faint">{timeAgo(report.createdAt)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
