"use client";

import { useEffect, useState } from "react";
import { Bell } from "lucide-react";
import Link from "next/link";
import { timeAgo } from "@/lib/utils";

interface Notif {
  id: string;
  message: string;
  reportId: string | null;
  read: boolean;
  createdAt: string;
  type: string;
}

export default function NotificationBell() {
  const [items, setItems] = useState<Notif[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    let active = true;
    async function load() {
      const res = await fetch("/api/notifications");
      const data = await res.json();
      if (active) setItems(data.notifications || []);
    }
    load();
    const id = setInterval(load, 15000); // polling stands in for Socket.io push
    return () => {
      active = false;
      clearInterval(id);
    };
  }, []);

  const unread = items.filter((i) => !i.read).length;

  return (
    <div className="relative">
      <button
        onClick={async () => {
          setOpen((v) => !v);
          if (unread > 0) {
            await fetch("/api/notifications", { method: "PATCH" });
            setItems((prev) => prev.map((i) => ({ ...i, read: true })));
          }
        }}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        className="relative flex h-8 w-8 items-center justify-center rounded-full hover:bg-line transition-colors"
        aria-label="Notifications"
      >
        <Bell size={16} strokeWidth={2} className="text-ink-soft" />
        {unread > 0 && (
          <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-red-500" />
        )}
      </button>
      {open && (
        <div className="absolute right-0 top-10 w-80 max-h-96 overflow-y-auto rounded-md border border-border bg-surface shadow-pop animate-fade-up">
          <div className="sticky top-0 bg-surface px-3.5 py-2.5 border-b border-line">
            <p className="text-[13px] font-semibold text-ink">Notifications</p>
          </div>
          {items.length === 0 ? (
            <p className="px-3.5 py-6 text-center text-[12px] text-ink-faint">
              You&apos;re all caught up. Nothing here yet.
            </p>
          ) : (
            <ul className="divide-y divide-line">
              {items.map((n) => (
                <li key={n.id}>
                  <Link
                    href={n.reportId ? `/issue/${n.reportId}` : "#"}
                    className="block px-3.5 py-2.5 hover:bg-fog transition-colors"
                  >
                    <p className="text-[12.5px] leading-snug text-ink-soft">{n.message}</p>
                    <p className="text-[11px] text-ink-faint mt-0.5">{timeAgo(n.createdAt)}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
