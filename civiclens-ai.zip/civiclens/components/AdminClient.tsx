"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/components/AuthProvider";
import { useToast } from "@/components/ToastProvider";
import { CATEGORY_META, STATUS_META, timeAgo } from "@/lib/utils";
import { SeverityBadge, PriorityPill } from "@/components/Badges";
import CategoryIcon from "@/components/CategoryIcon";
import { ShieldAlert, Flag, ArrowUp } from "lucide-react";
import type { IssueStatus, Report } from "@/types";

export default function AdminClient() {
  const { user, loading: authLoading } = useAuth();
  const { push } = useToast();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<IssueStatus | "">("");

  async function load() {
    const params = new URLSearchParams({ limit: "200" });
    if (statusFilter) params.set("status", statusFilter);
    const res = await fetch(`/api/reports?${params.toString()}`);
    const data = await res.json();
    setReports(data.reports || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  async function updateStatus(id: string, status: IssueStatus) {
    const res = await fetch(`/api/reports/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      const data = await res.json();
      setReports((prev) => prev.map((r) => (r.id === id ? data.report : r)));
      push("success", `Marked as ${STATUS_META[status].label}.`);
    }
  }

  async function toggleSpam(id: string, spam: boolean) {
    const res = await fetch(`/api/reports/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ spam }),
    });
    if (res.ok) {
      const data = await res.json();
      setReports((prev) => prev.map((r) => (r.id === id ? data.report : r)));
      push("success", spam ? "Flagged as spam." : "Restored.");
    }
  }

  if (!authLoading && (!user || user.role !== "admin")) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <ShieldAlert className="mx-auto mb-3 text-amber-500" size={28} />
        <p className="text-[14px] font-medium text-ink mb-1">Admin access required</p>
        <p className="text-[13px] text-ink-muted mb-4">Sign in with a municipal admin account to view this page.</p>
        <Link href="/login" className="text-teal-600 text-[13px] font-medium hover:underline">Go to sign in</Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="font-display font-bold text-[22px] tracking-tightest text-ink">Admin console</h1>
          <p className="text-[13px] text-ink-muted mt-1">Verify reports, manage the status pipeline, and remove spam.</p>
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as IssueStatus | "")}
          className="rounded-sm border border-border bg-surface px-3 py-2 text-[12.5px] text-ink-soft outline-none focus:border-teal-500"
        >
          <option value="">All statuses</option>
          {Object.entries(STATUS_META).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-16 skeleton rounded-md" />)}
        </div>
      ) : (
        <div className="border border-border rounded-lg overflow-hidden bg-surface">
          <div className="grid grid-cols-[1fr,110px,90px,90px,200px] gap-2 px-4 py-2.5 bg-fog border-b border-line text-[10.5px] font-semibold uppercase tracking-wide text-ink-faint">
            <span>Report</span>
            <span>Severity</span>
            <span>Priority</span>
            <span>Votes</span>
            <span>Actions</span>
          </div>
          {reports.map((r) => (
            <div key={r.id} className={`grid grid-cols-[1fr,110px,90px,90px,200px] gap-2 px-4 py-3 border-b border-line last:border-0 items-center ${r.spam ? "opacity-50" : ""}`}>
              <div className="min-w-0">
                <Link href={`/issue/${r.id}`} className="flex items-center gap-1.5 text-[13px] font-medium text-ink hover:text-teal-700 truncate">
                  <CategoryIcon category={r.category} size={12} className="text-ink-faint shrink-0" />
                  {r.title}
                </Link>
                <p className="text-[11px] text-ink-faint mt-0.5">{CATEGORY_META[r.category].label} · {timeAgo(r.createdAt)} · {STATUS_META[r.status].label}</p>
              </div>
              <SeverityBadge severity={r.severity} />
              <PriorityPill score={r.priorityScore} />
              <span className="flex items-center gap-1 text-[12px] text-ink-muted"><ArrowUp size={11} /> {r.votes}</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {r.status !== "verified" && r.status !== "resolved" && (
                  <button onClick={() => updateStatus(r.id, "verified")} className="rounded-xs border border-teal-300 bg-teal-50 px-2 py-1 text-[10.5px] font-medium text-teal-700 hover:bg-teal-100">
                    Verify
                  </button>
                )}
                {r.status !== "resolved" && (
                  <button onClick={() => updateStatus(r.id, "resolved")} className="rounded-xs border border-border px-2 py-1 text-[10.5px] font-medium text-ink-soft hover:bg-fog">
                    Resolve
                  </button>
                )}
                <button onClick={() => toggleSpam(r.id, !r.spam)} className="rounded-xs border border-red-50 px-2 py-1 text-[10.5px] font-medium text-red-600 hover:bg-red-50 flex items-center gap-1">
                  <Flag size={10} /> {r.spam ? "Restore" : "Spam"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
