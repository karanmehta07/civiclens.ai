"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import {
  ArrowUp, MessageSquare, MapPin, Sparkles, Loader2, ArrowLeft,
  CheckCircle2, ShieldCheck, Flag,
} from "lucide-react";
import { CATEGORY_META, formatCoord, timeAgo } from "@/lib/utils";
import { SeverityBadge, PriorityPill } from "@/components/Badges";
import CategoryIcon from "@/components/CategoryIcon";
import StatusLine from "@/components/StatusLine";
import { useAuth } from "@/components/AuthProvider";
import { useToast } from "@/components/ToastProvider";
import type { Comment, IssueStatus, Report } from "@/types";
import { STATUS_PIPELINE, STATUS_META } from "@/lib/utils";

const MiniMap = dynamic(() => import("@/components/MapView"), { ssr: false, loading: () => <div className="h-full w-full skeleton" /> });

export default function IssueDetailClient({ id }: { id: string }) {
  const { user } = useAuth();
  const { push } = useToast();
  const [report, setReport] = useState<Report | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [voting, setVoting] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [posting, setPosting] = useState(false);
  const [notFound, setNotFound] = useState(false);

  async function load() {
    const res = await fetch(`/api/reports/${id}`);
    if (res.status === 404) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    const data = await res.json();
    setReport(data.report);
    setComments(data.comments);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function vote(confirm: boolean) {
    if (!user) {
      push("info", "Sign in to vote on this issue.");
      return;
    }
    setVoting(true);
    const res = await fetch(`/api/reports/${id}/vote`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirm }),
    });
    const data = await res.json();
    setVoting(false);
    if (!res.ok) {
      push("error", data.error || "Couldn't register your vote.");
      return;
    }
    setReport(data.report);
    push("success", confirm ? "Confirmed — thanks for verifying this on the ground." : "Upvoted.");
  }

  async function postComment() {
    if (!user) {
      push("info", "Sign in to comment.");
      return;
    }
    if (!commentText.trim()) return;
    setPosting(true);
    const res = await fetch(`/api/reports/${id}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: commentText }),
    });
    const data = await res.json();
    setPosting(false);
    if (!res.ok) {
      push("error", data.error || "Couldn't post comment.");
      return;
    }
    setComments((prev) => [...prev, data.comment]);
    setCommentText("");
  }

  async function updateStatus(status: IssueStatus) {
    const res = await fetch(`/api/reports/${id}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (!res.ok) {
      push("error", data.error || "Couldn't update status.");
      return;
    }
    setReport(data.report);
    push("success", `Status updated to ${STATUS_META[status].label}.`);
  }

  if (notFound) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center">
        <p className="text-[15px] font-medium text-ink mb-1">Report not found</p>
        <p className="text-[13px] text-ink-muted mb-4">It may have been removed, or the link is incorrect.</p>
        <Link href="/" className="text-teal-600 text-[13px] font-medium hover:underline">← Back to map</Link>
      </div>
    );
  }

  if (loading || !report) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8 space-y-4">
        <div className="h-8 w-40 skeleton rounded-sm" />
        <div className="h-64 skeleton rounded-lg" />
      </div>
    );
  }

  const meta = CATEGORY_META[report.category];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
      <Link href="/" className="inline-flex items-center gap-1.5 text-[12.5px] text-ink-muted hover:text-ink mb-4">
        <ArrowLeft size={13} /> Back to map
      </Link>

      <div className="grid md:grid-cols-[1fr,320px] gap-5">
        <div className="space-y-5">
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            {report.imageUrl ? (
              <img src={report.imageUrl} alt="" className="w-full h-72 object-cover" />
            ) : (
              <div className="w-full h-40 flex items-center justify-center" style={{ backgroundColor: `${meta.color}0f` }}>
                <CategoryIcon category={report.category} size={40} className="opacity-30" />
              </div>
            )}
            <div className="p-5">
              <div className="flex items-center gap-1.5 mb-2">
                <CategoryIcon category={report.category} size={13} className="text-ink-faint" />
                <span className="text-[11.5px] font-mono uppercase tracking-wide text-ink-faint">{meta.label}</span>
                <span className="text-ink-faint">·</span>
                <span className="text-[11.5px] text-ink-faint">{timeAgo(report.createdAt)}</span>
              </div>
              <h1 className="font-display font-bold text-[21px] tracking-tightest text-ink leading-snug mb-2">{report.title}</h1>
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <SeverityBadge severity={report.severity} />
                <PriorityPill score={report.priorityScore} />
                <span className="text-[11.5px] text-ink-faint">Reported by {report.reporterName}</span>
              </div>
              {report.description && <p className="text-[13.5px] text-ink-soft leading-relaxed mb-4">{report.description}</p>}

              <div className="flex items-center gap-1.5 text-[12px] font-mono text-ink-faint mb-4">
                <MapPin size={12} /> {formatCoord(report.lat)}, {formatCoord(report.lng)}
                {report.address && <span>· {report.address}</span>}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => vote(false)}
                  disabled={voting || report.voterIds.includes(user?.id || "")}
                  className="flex items-center gap-1.5 rounded-sm border border-border px-3.5 py-2 text-[13px] font-medium text-ink-soft hover:border-teal-300 disabled:opacity-50"
                >
                  <ArrowUp size={14} /> Upvote · {report.votes}
                </button>
                <button
                  onClick={() => vote(true)}
                  disabled={voting || report.voterIds.includes(user?.id || "")}
                  className="flex items-center gap-1.5 rounded-sm bg-teal-500 px-3.5 py-2 text-[13px] font-medium text-white hover:bg-teal-600 disabled:opacity-50"
                >
                  <CheckCircle2 size={14} /> Confirm on the ground
                </button>
              </div>
            </div>
          </div>

          {report.aiVerification && (
            <div className="bg-surface border border-border rounded-lg p-5">
              <div className="flex items-center gap-1.5 mb-3 text-teal-700">
                <Sparkles size={14} />
                <p className="text-[13px] font-semibold">AI photo verification</p>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <p className="text-[11px] text-ink-faint mb-0.5">Confidence</p>
                  <p className="text-[16px] font-mono font-semibold text-ink">{(report.aiVerification.confidence * 100).toFixed(0)}%</p>
                </div>
                <div>
                  <p className="text-[11px] text-ink-faint mb-0.5">AI-suggested severity</p>
                  <SeverityBadge severity={report.aiVerification.suggestedSeverity} />
                </div>
              </div>
              <p className="text-[12.5px] text-ink-muted mb-2">{report.aiVerification.reasoning}</p>
              <p className="text-[10.5px] font-mono text-ink-faint">{report.aiVerification.model}</p>
            </div>
          )}

          <div className="bg-surface border border-border rounded-lg p-5">
            <p className="text-[13px] font-semibold text-ink mb-3 flex items-center gap-1.5">
              <MessageSquare size={14} /> Comments · {comments.length}
            </p>
            <div className="space-y-3 mb-4">
              {comments.length === 0 ? (
                <p className="text-[12.5px] text-ink-faint">No comments yet. Be the first to add context.</p>
              ) : (
                comments.map((c) => (
                  <div key={c.id} className="flex gap-2.5">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-teal-100 text-[11px] font-semibold text-teal-700">
                      {c.userName.charAt(0).toUpperCase()}
                    </span>
                    <div>
                      <p className="text-[12.5px]"><span className="font-medium text-ink">{c.userName}</span> <span className="text-ink-faint text-[11px]">· {timeAgo(c.createdAt)}</span></p>
                      <p className="text-[13px] text-ink-soft mt-0.5">{c.text}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
            <div className="flex gap-2">
              <input
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && postComment()}
                placeholder={user ? "Add a comment…" : "Sign in to comment…"}
                disabled={!user}
                className="flex-1 rounded-sm border border-border px-3 py-2 text-[13px] outline-none focus:border-teal-500 disabled:bg-fog"
              />
              <button
                onClick={postComment}
                disabled={posting || !user}
                className="rounded-sm bg-ink px-3.5 py-2 text-[13px] font-medium text-white hover:bg-ink-soft disabled:opacity-50"
              >
                {posting ? <Loader2 size={14} className="animate-spin" /> : "Post"}
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-5">
          <div className="bg-surface border border-border rounded-lg p-4">
            <p className="text-[12px] font-semibold text-ink-soft mb-2">Status pipeline</p>
            <StatusLine status={report.status} />

            {user?.role === "admin" && (
              <div className="mt-4 pt-4 border-t border-line">
                <p className="text-[11.5px] font-medium text-ink-faint mb-2 flex items-center gap-1"><ShieldCheck size={12} /> Admin controls</p>
                <div className="grid grid-cols-2 gap-1.5">
                  {STATUS_PIPELINE.map((s) => (
                    <button
                      key={s}
                      onClick={() => updateStatus(s)}
                      disabled={report.status === s}
                      className={`rounded-sm border px-2 py-1.5 text-[11px] font-medium ${
                        report.status === s ? "bg-teal-50 border-teal-300 text-teal-700" : "border-border text-ink-muted hover:border-teal-300"
                      }`}
                    >
                      {STATUS_META[s].label}
                    </button>
                  ))}
                </div>
                <button
                  onClick={async () => {
                    const res = await fetch(`/api/reports/${id}/status`, {
                      method: "PATCH",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ spam: !report.spam }),
                    });
                    const data = await res.json();
                    if (res.ok) {
                      setReport(data.report);
                      push("success", report.spam ? "Report restored." : "Report flagged as spam and hidden from the map.");
                    }
                  }}
                  className="mt-2 w-full flex items-center justify-center gap-1.5 rounded-sm border border-red-50 bg-red-50 px-2 py-1.5 text-[11px] font-medium text-red-600 hover:bg-red-100"
                >
                  <Flag size={11} /> {report.spam ? "Restore report" : "Flag as spam"}
                </button>
              </div>
            )}
          </div>

          <div className="bg-surface border border-border rounded-lg overflow-hidden h-56">
            <MiniMap reports={[report]} center={[report.lat, report.lng]} />
          </div>

          <div className="bg-surface border border-border rounded-lg p-4 space-y-2">
            <p className="text-[12px] font-semibold text-ink-soft mb-1">Report details</p>
            <DetailRow label="Report ID" value={report.id} mono />
            <DetailRow label="Votes" value={String(report.votes)} />
            <DetailRow label="Confirmations" value={String(report.confirmCount)} />
            <DetailRow label="Priority score" value={report.priorityScore.toFixed(1)} />
            <DetailRow label="Filed" value={new Date(report.createdAt).toLocaleDateString()} />
          </div>
        </div>
      </div>
    </div>
  );
}

function DetailRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[11.5px] text-ink-faint">{label}</span>
      <span className={`text-[12px] text-ink-soft ${mono ? "font-mono" : "font-medium"}`}>{value}</span>
    </div>
  );
}
