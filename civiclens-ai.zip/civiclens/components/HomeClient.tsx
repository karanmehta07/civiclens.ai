"use client";

import { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { Plus, Search, SlidersHorizontal, X } from "lucide-react";
import IssueCard from "@/components/IssueCard";
import ReportModal from "@/components/ReportModal";
import { CATEGORY_META, STATUS_META } from "@/lib/utils";
import type { IssueCategory, IssueStatus, Report, Severity } from "@/types";
import { useAuth } from "@/components/AuthProvider";
import { useToast } from "@/components/ToastProvider";

const MapView = dynamic(() => import("@/components/MapView"), {
  ssr: false,
  loading: () => <div className="h-full w-full skeleton" />,
});

const AHMEDABAD: [number, number] = [23.0225, 72.5714];

export default function HomeClient() {
  const { user } = useAuth();
  const { push } = useToast();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState<{ lat: number; lng: number } | null>(null);
  const [filterOpen, setFilterOpen] = useState(false);
  const [category, setCategory] = useState<IssueCategory | "">("");
  const [status, setStatus] = useState<IssueStatus | "">("");
  const [severity, setSeverity] = useState<Severity | "">("");
  const [query, setQuery] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  async function load() {
    const params = new URLSearchParams();
    if (category) params.set("category", category);
    if (status) params.set("status", status);
    if (severity) params.set("severity", severity);
    if (query) params.set("q", query);
    const res = await fetch(`/api/reports?${params.toString()}`);
    const data = await res.json();
    setReports(data.reports || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    const id = setInterval(load, 20000); // polling stands in for Socket.io live updates
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, status, severity, query]);

  const stats = useMemo(() => {
    const active = reports.filter((r) => r.status !== "resolved").length;
    const critical = reports.filter((r) => r.severity === "critical").length;
    return { total: reports.length, active, critical };
  }, [reports]);

  return (
    <div className="h-[calc(100vh-90px)] md:h-[calc(100vh-56px)] flex flex-col">
      {/* Hero strip */}
      <div className="border-b border-line bg-surface px-4 sm:px-6 py-3 flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display font-bold text-[19px] tracking-tightest text-ink leading-none">
            See it. Report it. <span className="text-teal-500">Fix it.</span>
          </h1>
          <p className="text-[12px] text-ink-muted mt-1">
            {loading ? "Loading live civic reports…" : `${stats.total} reports on the map · ${stats.active} active · ${stats.critical} critical`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 rounded-full border border-border bg-fog px-3 py-1.5">
            <Search size={13} className="text-ink-faint" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search reports…"
              className="bg-transparent outline-none text-[12.5px] w-40"
            />
          </div>
          <button
            onClick={() => setFilterOpen((v) => !v)}
            className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 text-[12.5px] font-medium text-ink-soft hover:border-teal-300"
          >
            <SlidersHorizontal size={13} /> Filters
          </button>
          <button
            onClick={() => setSidebarOpen((v) => !v)}
            className="md:hidden rounded-full border border-border px-3 py-1.5 text-[12.5px] font-medium text-ink-soft"
          >
            {sidebarOpen ? "Map" : "List"}
          </button>
        </div>
      </div>

      {filterOpen && (
        <div className="border-b border-line bg-surface px-4 sm:px-6 py-3 flex flex-wrap gap-2 animate-fade-up">
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as IssueCategory | "")}
            className="rounded-sm border border-border bg-surface px-2.5 py-1.5 text-[12px] text-ink-soft outline-none focus:border-teal-500"
          >
            <option value="">All categories</option>
            {Object.entries(CATEGORY_META).map(([k, v]) => (
              <option key={k} value={k}>{v.label}</option>
            ))}
          </select>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as IssueStatus | "")}
            className="rounded-sm border border-border bg-surface px-2.5 py-1.5 text-[12px] text-ink-soft outline-none focus:border-teal-500"
          >
            <option value="">All statuses</option>
            {Object.entries(STATUS_META).map(([k, v]) => (
              <option key={k} value={k}>{v.label}</option>
            ))}
          </select>
          <select
            value={severity}
            onChange={(e) => setSeverity(e.target.value as Severity | "")}
            className="rounded-sm border border-border bg-surface px-2.5 py-1.5 text-[12px] text-ink-soft outline-none focus:border-teal-500"
          >
            <option value="">All severities</option>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="critical">Critical</option>
          </select>
          {(category || status || severity || query) && (
            <button
              onClick={() => {
                setCategory("");
                setStatus("");
                setSeverity("");
                setQuery("");
              }}
              className="flex items-center gap-1 text-[12px] text-ink-faint hover:text-ink"
            >
              <X size={12} /> Clear
            </button>
          )}
        </div>
      )}

      <div className="flex-1 flex overflow-hidden relative">
        <div className={`${sidebarOpen ? "flex" : "hidden"} md:flex flex-col w-full md:w-[360px] border-r border-line bg-fog overflow-y-auto shrink-0`}>
          {loading ? (
            <div className="p-3.5 space-y-2.5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-20 rounded-md skeleton" />
              ))}
            </div>
          ) : reports.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-[13px] text-ink-muted">No reports match your filters yet.</p>
            </div>
          ) : (
            <div className="p-3.5 space-y-2.5">
              {reports.map((r) => (
                <IssueCard key={r.id} report={r} />
              ))}
            </div>
          )}
        </div>

        <div className={`${sidebarOpen ? "hidden" : "block"} md:block flex-1 relative`}>
          <MapView
            reports={reports}
            center={AHMEDABAD}
            onMapClick={(lat, lng) => {
              if (!user) {
                push("info", "Sign in to report an issue on the map.");
              }
              setPending({ lat, lng });
            }}
          />

          <button
            onClick={() => {
              if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                  (pos) => setPending({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
                  () => setPending({ lat: AHMEDABAD[0], lng: AHMEDABAD[1] })
                );
              } else {
                setPending({ lat: AHMEDABAD[0], lng: AHMEDABAD[1] });
              }
            }}
            className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[500] flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-[13px] font-semibold text-white shadow-pop hover:bg-ink-soft transition-colors md:left-auto md:right-16 md:translate-x-0"
          >
            <Plus size={16} /> Report issue
          </button>
        </div>
      </div>

      {pending && (
        <ReportModal
          lat={pending.lat}
          lng={pending.lng}
          onClose={() => setPending(null)}
          onCreated={(report) => {
            setReports((prev) => [report, ...prev]);
            setPending(null);
          }}
        />
      )}
    </div>
  );
}
