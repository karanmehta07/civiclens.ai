"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import NotificationBell from "@/components/NotificationBell";
import { cn } from "@/lib/utils";
import { Map, LayoutDashboard, Trophy, Recycle, ShieldCheck, LogOut, User as UserIcon } from "lucide-react";
import { useState } from "react";

const LINKS = [
  { href: "/", label: "Map", icon: Map },
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { href: "/waste-sorter", label: "Waste Sorter", icon: Recycle },
];

export default function NavBar() {
  const pathname = usePathname();
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 inset-x-0 z-[900] border-b border-border bg-surface/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[1400px] items-center justify-between px-4 sm:px-6">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-teal-500 opacity-60" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-teal-500" />
            </span>
            <span className="font-display font-bold tracking-tightest text-[17px] text-ink">
              CivicLens<span className="text-teal-500"> AI</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {LINKS.map((l) => {
              const active = pathname === l.href;
              const Icon = l.icon;
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  className={cn(
                    "flex items-center gap-1.5 rounded-sm px-3 py-1.5 text-[13px] font-medium transition-colors",
                    active ? "bg-teal-50 text-teal-700" : "text-ink-muted hover:text-ink hover:bg-line"
                  )}
                >
                  <Icon size={14} strokeWidth={2.25} />
                  {l.label}
                </Link>
              );
            })}
            {user?.role === "admin" && (
              <Link
                href="/admin"
                className={cn(
                  "flex items-center gap-1.5 rounded-sm px-3 py-1.5 text-[13px] font-medium transition-colors",
                  pathname === "/admin" ? "bg-amber-50 text-amber-600" : "text-ink-muted hover:text-ink hover:bg-line"
                )}
              >
                <ShieldCheck size={14} strokeWidth={2.25} />
                Admin
              </Link>
            )}
          </nav>
        </div>

        <div className="flex items-center gap-2">
          {!loading && user && <NotificationBell />}

          {!loading && !user && (
            <div className="flex items-center gap-2">
              <Link
                href="/login"
                className="rounded-sm px-3 py-1.5 text-[13px] font-medium text-ink-muted hover:text-ink"
              >
                Sign in
              </Link>
              <Link
                href="/register"
                className="rounded-sm bg-ink px-3.5 py-1.5 text-[13px] font-medium text-white hover:bg-ink-soft transition-colors"
              >
                Get started
              </Link>
            </div>
          )}

          {!loading && user && (
            <div className="relative">
              <button
                onClick={() => setMenuOpen((v) => !v)}
                onBlur={() => setTimeout(() => setMenuOpen(false), 150)}
                className="flex items-center gap-2 rounded-sm py-1 pl-1 pr-2.5 hover:bg-line transition-colors"
              >
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-teal-500 text-[11px] font-semibold text-white">
                  {user.name.charAt(0).toUpperCase()}
                </span>
                <span className="hidden sm:block text-[13px] font-medium text-ink-soft max-w-[100px] truncate">
                  {user.name.split(" ")[0]}
                </span>
                <span className="hidden sm:block text-[11px] font-mono text-amber-600">{user.points}pt</span>
              </button>
              {menuOpen && (
                <div className="absolute right-0 top-11 w-52 rounded-md border border-border bg-surface shadow-pop p-1.5 animate-fade-up">
                  <div className="px-2.5 py-2 border-b border-line mb-1">
                    <p className="text-[13px] font-medium text-ink truncate">{user.name}</p>
                    <p className="text-[12px] text-ink-faint truncate">{user.email}</p>
                  </div>
                  <div className="px-2.5 py-1.5 text-[12px] text-ink-muted flex items-center gap-1.5">
                    <UserIcon size={12} /> {user.points} contribution points
                  </div>
                  <button
                    onClick={async () => {
                      await logout();
                      router.refresh();
                    }}
                    className="w-full flex items-center gap-1.5 rounded-xs px-2.5 py-1.5 text-[13px] text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <LogOut size={13} /> Sign out
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <nav className="md:hidden flex items-center gap-1 overflow-x-auto border-t border-line px-3 py-1.5 bg-surface">
        {LINKS.map((l) => {
          const Icon = l.icon;
          const active = pathname === l.href;
          return (
            <Link
              key={l.href}
              href={l.href}
              className={cn(
                "flex items-center gap-1 whitespace-nowrap rounded-sm px-2.5 py-1 text-[12px] font-medium",
                active ? "bg-teal-50 text-teal-700" : "text-ink-muted"
              )}
            >
              <Icon size={12} /> {l.label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
