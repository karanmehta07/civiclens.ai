"use client";

import { STATUS_PIPELINE, STATUS_META } from "@/lib/utils";
import type { IssueStatus } from "@/types";
import { Check } from "lucide-react";

export default function StatusLine({
  status,
  compact = false,
}: {
  status: IssueStatus;
  compact?: boolean;
}) {
  const currentIndex = STATUS_PIPELINE.indexOf(status);
  const fillPct = (currentIndex / (STATUS_PIPELINE.length - 1)) * 100;

  return (
    <div className={compact ? "py-1" : "py-2"}>
      <div className="transit-line h-2.5">
        <div className="transit-line-fill" style={{ width: `${fillPct}%` }} />
        {STATUS_PIPELINE.map((s, i) => (
          <div
            key={s}
            className={`transit-stop ${i < currentIndex ? "is-done" : ""} ${
              i === currentIndex ? "is-current" : ""
            }`}
            title={STATUS_META[s].label}
          >
            {i < currentIndex && !compact && (
              <Check size={7} className="absolute inset-0 m-auto text-white" strokeWidth={3.5} />
            )}
          </div>
        ))}
      </div>
      {!compact && (
        <div className="flex justify-between mt-1.5">
          {STATUS_PIPELINE.map((s, i) => (
            <span
              key={s}
              className={`text-[10px] font-mono uppercase tracking-wide ${
                i <= currentIndex ? "text-teal-600 font-medium" : "text-ink-faint"
              }`}
              style={{ width: `${100 / STATUS_PIPELINE.length}%`, textAlign: i === 0 ? "left" : i === STATUS_PIPELINE.length - 1 ? "right" : "center" }}
            >
              {STATUS_META[s].label}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
