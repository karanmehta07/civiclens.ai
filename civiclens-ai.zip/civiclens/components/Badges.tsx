import { SEVERITY_META } from "@/lib/utils";
import { priorityTier } from "@/lib/priority";
import type { Severity } from "@/types";

export function SeverityBadge({ severity }: { severity: Severity }) {
  const meta = SEVERITY_META[severity];
  return (
    <span
      className="inline-flex items-center rounded-xs px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide"
      style={{ color: meta.color, backgroundColor: meta.bg }}
    >
      {meta.label}
    </span>
  );
}

const TIER_STYLE: Record<string, string> = {
  Critical: "bg-red-500 text-white",
  High: "bg-amber-300 text-ink",
  Medium: "bg-teal-100 text-teal-700",
  Low: "bg-line text-ink-muted",
};

export function PriorityPill({ score }: { score: number }) {
  const tier = priorityTier(score);
  return (
    <span className={`inline-flex items-center gap-1 rounded-xs px-1.5 py-0.5 text-[10px] font-semibold ${TIER_STYLE[tier]}`}>
      {tier} <span className="font-mono opacity-80">{score.toFixed(0)}</span>
    </span>
  );
}
