import {
  CircleDashed,
  Trash2,
  ArchiveX,
  LightbulbOff,
  Droplets,
  Construction,
  TreeDeciduous,
  OctagonAlert,
  TriangleAlert,
  type LucideIcon,
} from "lucide-react";
import type { IssueCategory } from "@/types";

const ICON_MAP: Record<IssueCategory, LucideIcon> = {
  pothole: CircleDashed,
  garbage: Trash2,
  overflowing_bin: ArchiveX,
  streetlight: LightbulbOff,
  water_leak: Droplets,
  road_damage: Construction,
  fallen_tree: TreeDeciduous,
  open_manhole: OctagonAlert,
  hazard: TriangleAlert,
};

export default function CategoryIcon({
  category,
  size = 15,
  className,
}: {
  category: IssueCategory;
  size?: number;
  className?: string;
}) {
  const Icon = ICON_MAP[category] || TriangleAlert;
  return <Icon size={size} strokeWidth={2} className={className} />;
}
