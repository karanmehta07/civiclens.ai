"use client";

import { useRef, useState } from "react";
import { X, Camera, Loader2, Sparkles, TriangleAlert, CheckCircle2, MapPin } from "lucide-react";
import { CATEGORY_META, SEVERITY_META, formatCoord } from "@/lib/utils";
import type { AIVerification, IssueCategory, Report, Severity } from "@/types";
import { useToast } from "@/components/ToastProvider";
import { useAuth } from "@/components/AuthProvider";
import { useRouter } from "next/navigation";

const CATEGORIES = Object.entries(CATEGORY_META) as [IssueCategory, typeof CATEGORY_META[IssueCategory]][];
const SEVERITIES: Severity[] = ["low", "medium", "high", "critical"];

export default function ReportModal({
  lat,
  lng,
  onClose,
  onCreated,
}: {
  lat: number;
  lng: number;
  onClose: () => void;
  onCreated: (report: Report) => void;
}) {
  const { user } = useAuth();
  const { push } = useToast();
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<IssueCategory>("pothole");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState<Severity | null>(null);
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState<AIVerification | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [duplicate, setDuplicate] = useState<Report | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!user) {
    return (
      <ModalShell onClose={onClose}>
        <div className="p-6 text-center">
          <TriangleAlert className="mx-auto mb-3 text-amber-500" size={28} />
          <p className="text-[14px] font-medium text-ink mb-1">Sign in to report an issue</p>
          <p className="text-[13px] text-ink-muted mb-4">
            CivicLens AI needs an account to attribute reports and award contribution points.
          </p>
          <button
            onClick={() => router.push("/login")}
            className="rounded-sm bg-teal-500 px-4 py-2 text-[13px] font-medium text-white hover:bg-teal-600"
          >
            Go to sign in
          </button>
        </div>
      </ModalShell>
    );
  }

  async function handlePhoto(f: File) {
    setPhoto(f);
    setPreview(URL.createObjectURL(f));
    setAiResult(null);
    setAnalyzing(true);
    try {
      const fd = new FormData();
      fd.append("photo", f);
      fd.append("category", category);
      const res = await fetch("/api/reports/analyze", { method: "POST", body: fd }).catch(() => null);
      if (res && res.ok) {
        const data = await res.json();
        if (data.aiVerification) {
          setAiResult(data.aiVerification);
          setSeverity(data.aiVerification.suggestedSeverity);
        }
      }
    } finally {
      setAnalyzing(false);
    }
  }

  async function submit(forceCreate = false) {
    if (!title.trim()) {
      setError("Give the issue a short title.");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append("title", title.trim());
      fd.append("category", category);
      fd.append("description", description.trim());
      fd.append("lat", String(lat));
      fd.append("lng", String(lng));
      if (severity) fd.append("severity", severity);
      if (photo) fd.append("photo", photo);
      if (forceCreate) fd.append("forceCreate", "true");

      const res = await fetch("/api/reports", { method: "POST", body: fd });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Something went wrong.");
        return;
      }
      if (data.duplicate) {
        setDuplicate(data.existing);
        return;
      }
      push("success", "Issue reported. Thanks for helping keep the city on track.");
      onCreated(data.report);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (duplicate) {
    return (
      <ModalShell onClose={onClose}>
        <div className="p-5">
          <div className="flex items-center gap-2 mb-3 text-amber-600">
            <TriangleAlert size={18} />
            <p className="text-[14px] font-semibold">Possible duplicate found</p>
          </div>
          <p className="text-[13px] text-ink-muted mb-4">
            A similar report already exists nearby for this category. You can support the existing
            report instead, or create a new one anyway if this is genuinely a separate issue.
          </p>
          <div className="rounded-md border border-border p-3 mb-4">
            <p className="text-[13px] font-medium text-ink mb-1">{duplicate.title}</p>
            <p className="text-[12px] text-ink-faint">
              {duplicate.votes} votes · {CATEGORY_META[duplicate.category].label}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={async () => {
                await fetch(`/api/reports/${duplicate.id}/vote`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ confirm: true }),
                });
                push("success", "Thanks — you've confirmed the existing report.");
                onClose();
                router.push(`/issue/${duplicate.id}`);
              }}
              className="flex-1 rounded-sm bg-teal-500 px-3 py-2 text-[13px] font-medium text-white hover:bg-teal-600"
            >
              Support existing report
            </button>
            <button
              onClick={() => submit(true)}
              disabled={submitting}
              className="flex-1 rounded-sm border border-border px-3 py-2 text-[13px] font-medium text-ink-soft hover:bg-fog"
            >
              {submitting ? "Creating…" : "Create new report"}
            </button>
          </div>
        </div>
      </ModalShell>
    );
  }

  return (
    <ModalShell onClose={onClose} title="Report an issue">
      <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
        <div className="flex items-center gap-1.5 text-[12px] text-ink-faint bg-fog rounded-sm px-2.5 py-1.5 font-mono">
          <MapPin size={12} /> {formatCoord(lat)}, {formatCoord(lng)}
        </div>

        <div>
          <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Title</label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            maxLength={120}
            placeholder="e.g. Deep pothole blocking left lane"
            className="w-full rounded-sm border border-border px-3 py-2 text-[13.5px] outline-none focus:border-teal-500 transition-colors"
          />
        </div>

        <div>
          <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Category</label>
          <div className="grid grid-cols-3 gap-1.5">
            {CATEGORIES.map(([key, meta]) => (
              <button
                key={key}
                type="button"
                onClick={() => setCategory(key)}
                className={`rounded-sm border px-2 py-1.5 text-[11.5px] font-medium text-left transition-colors ${
                  category === key ? "border-teal-500 bg-teal-50 text-teal-700" : "border-border text-ink-muted hover:border-teal-300"
                }`}
              >
                {meta.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Photo (recommended — enables AI verification)</label>
          {preview ? (
            <div className="relative">
              <img src={preview} alt="" className="w-full h-36 object-cover rounded-sm border border-line" />
              <button
                type="button"
                onClick={() => {
                  setPhoto(null);
                  setPreview(null);
                  setAiResult(null);
                }}
                className="absolute top-1.5 right-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-ink/70 text-white"
              >
                <X size={13} />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="w-full flex flex-col items-center justify-center gap-1.5 rounded-sm border border-dashed border-border py-6 text-ink-faint hover:border-teal-400 hover:text-teal-600 transition-colors"
            >
              <Camera size={20} />
              <span className="text-[12px]">Tap to upload a photo</span>
            </button>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handlePhoto(e.target.files[0])}
          />
        </div>

        {analyzing && (
          <div className="flex items-center gap-2 rounded-sm bg-fog px-3 py-2.5 text-[12.5px] text-ink-muted">
            <Loader2 size={14} className="animate-spin" /> Running AI photo verification…
          </div>
        )}

        {aiResult && (
          <div className="rounded-md border border-teal-100 bg-teal-50 p-3">
            <div className="flex items-center gap-1.5 mb-2 text-teal-700">
              <Sparkles size={13} />
              <p className="text-[12px] font-semibold">AI verification</p>
            </div>
            <div className="flex items-center justify-between text-[12.5px] mb-1">
              <span className="text-ink-muted">Confidence</span>
              <span className="font-mono font-medium text-ink">{(aiResult.confidence * 100).toFixed(0)}%</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-teal-100 mb-2 overflow-hidden">
              <div className="h-full bg-teal-500 rounded-full" style={{ width: `${aiResult.confidence * 100}%` }} />
            </div>
            <p className="text-[12px] text-ink-muted">{aiResult.reasoning}</p>
          </div>
        )}

        <div>
          <label className="block text-[12px] font-medium text-ink-soft mb-1.5">
            Severity {aiResult && <span className="text-ink-faint font-normal">(AI-suggested — you can correct it)</span>}
          </label>
          <div className="grid grid-cols-4 gap-1.5">
            {SEVERITIES.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSeverity(s)}
                className="rounded-sm border px-2 py-1.5 text-[11.5px] font-semibold text-center transition-colors"
                style={{
                  borderColor: severity === s ? SEVERITY_META[s].color : "#E3E7EC",
                  backgroundColor: severity === s ? SEVERITY_META[s].bg : "transparent",
                  color: severity === s ? SEVERITY_META[s].color : "#5B6470",
                }}
              >
                {SEVERITY_META[s].label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength={1000}
            rows={3}
            placeholder="Add any details that would help the municipal team (exact spot, how long it's been there, safety risk)…"
            className="w-full rounded-sm border border-border px-3 py-2 text-[13px] outline-none focus:border-teal-500 transition-colors resize-none"
          />
        </div>

        {error && (
          <p className="flex items-center gap-1.5 text-[12.5px] text-red-600">
            <TriangleAlert size={13} /> {error}
          </p>
        )}
      </div>

      <div className="flex items-center gap-2 border-t border-line p-4">
        <button
          onClick={onClose}
          className="flex-1 rounded-sm border border-border px-3 py-2.5 text-[13px] font-medium text-ink-soft hover:bg-fog"
        >
          Cancel
        </button>
        <button
          onClick={() => submit(false)}
          disabled={submitting || analyzing}
          className="flex-1 flex items-center justify-center gap-1.5 rounded-sm bg-teal-500 px-3 py-2.5 text-[13px] font-medium text-white hover:bg-teal-600 disabled:opacity-60"
        >
          {submitting ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
          Submit report
        </button>
      </div>
    </ModalShell>
  );
}

function ModalShell({
  children,
  onClose,
  title,
}: {
  children: React.ReactNode;
  onClose: () => void;
  title?: string;
}) {
  return (
    <div className="fixed inset-0 z-[1000] flex items-end sm:items-center justify-center bg-ink/40 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-md bg-surface rounded-t-lg sm:rounded-lg shadow-pop animate-fade-up max-h-[92vh] flex flex-col">
        {title && (
          <div className="flex items-center justify-between border-b border-line px-5 py-3.5 shrink-0">
            <p className="text-[14px] font-semibold text-ink">{title}</p>
            <button onClick={onClose} className="text-ink-faint hover:text-ink">
              <X size={17} />
            </button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
