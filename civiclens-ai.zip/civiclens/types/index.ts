export type IssueCategory =
  | "pothole"
  | "garbage"
  | "overflowing_bin"
  | "streetlight"
  | "water_leak"
  | "road_damage"
  | "fallen_tree"
  | "open_manhole"
  | "hazard";

export type Severity = "low" | "medium" | "high" | "critical";

export type IssueStatus =
  | "reported"
  | "verified"
  | "assigned"
  | "in_progress"
  | "resolved";

export interface AIVerification {
  detectedCategory: IssueCategory;
  confidence: number; // 0-1
  suggestedSeverity: Severity;
  labels: string[];
  reasoning: string;
  model: string;
}

export interface Report {
  id: string;
  title: string;
  category: IssueCategory;
  description: string;
  imageUrl: string | null;
  lat: number;
  lng: number;
  address: string | null;
  severity: Severity;
  aiVerification: AIVerification | null;
  status: IssueStatus;
  statusHistory: { status: IssueStatus; at: string }[];
  votes: number;
  voterIds: string[];
  confirmCount: number;
  reporterId: string;
  reporterName: string;
  priorityScore: number;
  spam: boolean;
  duplicateOf: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  id: string;
  reportId: string;
  userId: string;
  userName: string;
  text: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  role: "citizen" | "admin";
  points: number;
  badges: string[];
  authProvider: "credentials" | "google";
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: "verified" | "resolved" | "comment" | "vote_milestone";
  message: string;
  reportId: string | null;
  read: boolean;
  createdAt: string;
}

export interface DB {
  users: User[];
  reports: Report[];
  comments: Comment[];
  notifications: Notification[];
}
