import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/components/AuthProvider";
import { ToastProvider } from "@/components/ToastProvider";
import NavBar from "@/components/NavBar";

export const metadata: Metadata = {
  title: "CivicLens AI — See it. Report it. Fix it.",
  description:
    "Crowdsourced civic intelligence: report potholes, hazards, and infrastructure issues with AI-verified photos and community-driven priority.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-fog text-ink font-body antialiased">
        <AuthProvider>
          <ToastProvider>
            <NavBar />
            <main className="pt-[90px] md:pt-14">{children}</main>
          </ToastProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
