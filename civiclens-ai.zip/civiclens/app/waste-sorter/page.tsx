"use client";

import { useRef, useState } from "react";
import { Camera, Loader2, Recycle, X, CheckCircle2, XCircle } from "lucide-react";

interface WasteResult {
  type: string;
  confidence: number;
  recyclable: boolean;
  disposal: string;
  reasoning: string;
}

const TYPE_COLOR: Record<string, string> = {
  plastic: "#0F7A72",
  metal: "#5B6470",
  glass: "#0C6961",
  paper: "#DC8A15",
  organic: "#B36F0F",
};

export default function WasteSorterPage() {
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WasteResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleFile(f: File) {
    setPreview(URL.createObjectURL(f));
    setResult(null);
    setError(null);
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append("photo", f);
      const res = await fetch("/api/waste-sort", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Couldn't analyze this photo.");
      } else {
        setResult(data.result);
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto px-4 sm:px-6 py-8">
      <div className="mb-6 text-center">
        <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-teal-50 mb-3">
          <Recycle size={18} className="text-teal-600" />
        </span>
        <h1 className="font-display font-bold text-[22px] tracking-tightest text-ink">Smart Waste Sorter</h1>
        <p className="text-[13px] text-ink-muted mt-1">
          Upload a photo of an item to identify its material and how to dispose of it correctly.
        </p>
      </div>

      <div className="bg-surface border border-border rounded-lg p-5">
        {preview ? (
          <div className="relative mb-4">
            <img src={preview} alt="" className="w-full h-52 object-cover rounded-md border border-line" />
            <button
              onClick={() => {
                setPreview(null);
                setResult(null);
                setError(null);
              }}
              className="absolute top-2 right-2 flex h-7 w-7 items-center justify-center rounded-full bg-ink/70 text-white"
            >
              <X size={14} />
            </button>
          </div>
        ) : (
          <button
            onClick={() => fileRef.current?.click()}
            className="w-full flex flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border py-12 text-ink-faint hover:border-teal-400 hover:text-teal-600 transition-colors mb-4"
          >
            <Camera size={26} />
            <span className="text-[13px]">Upload a photo of the waste item</span>
          </button>
        )}
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />

        {loading && (
          <div className="flex items-center justify-center gap-2 py-3 text-[13px] text-ink-muted">
            <Loader2 size={15} className="animate-spin" /> Classifying material…
          </div>
        )}

        {error && <p className="text-[12.5px] text-red-600 text-center">{error}</p>}

        {result && (
          <div className="animate-fade-up">
            <div className="flex items-center justify-between mb-3">
              <span
                className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[13px] font-semibold capitalize"
                style={{ backgroundColor: `${TYPE_COLOR[result.type]}18`, color: TYPE_COLOR[result.type] }}
              >
                {result.type}
              </span>
              <span className="font-mono text-[13px] text-ink-muted">{(result.confidence * 100).toFixed(0)}% confidence</span>
            </div>

            <div className="w-full h-1.5 rounded-full bg-line mb-4 overflow-hidden">
              <div
                className="h-full rounded-full"
                style={{ width: `${result.confidence * 100}%`, backgroundColor: TYPE_COLOR[result.type] }}
              />
            </div>

            <div className="flex items-center gap-2 mb-3">
              {result.recyclable ? (
                <CheckCircle2 size={15} className="text-teal-600" />
              ) : (
                <XCircle size={15} className="text-amber-600" />
              )}
              <span className="text-[13px] font-medium text-ink">
                {result.recyclable ? "Recyclable" : "Not recyclable — compostable"}
              </span>
            </div>

            <div className="rounded-md bg-fog p-3 mb-2">
              <p className="text-[12.5px] text-ink-soft leading-relaxed">{result.disposal}</p>
            </div>
            <p className="text-[11px] text-ink-faint">{result.reasoning}</p>
          </div>
        )}
      </div>

      <p className="text-[11px] text-ink-faint text-center mt-4">
        Classification runs a lightweight on-device heuristic model. Swap in a trained detector via
        <span className="font-mono"> lib/ai/wasteSorter.ts</span> for production accuracy.
      </p>
    </div>
  );
}
