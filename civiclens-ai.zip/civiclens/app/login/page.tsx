"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { Loader2, LogIn, TriangleAlert } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const { refresh } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error || "Something went wrong.");
      return;
    }
    await refresh();
    router.push("/");
  }

  return (
    <div className="min-h-[calc(100vh-90px)] md:min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="text-center mb-7">
          <h1 className="font-display font-bold text-[22px] tracking-tightest text-ink">Welcome back</h1>
          <p className="text-[13px] text-ink-muted mt-1">Sign in to report and track civic issues.</p>
        </div>

        <form onSubmit={submit} className="bg-surface border border-border rounded-lg p-5 space-y-3.5 shadow-subtle">
          <div>
            <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-sm border border-border px-3 py-2 text-[13.5px] outline-none focus:border-teal-500"
            />
          </div>
          <div>
            <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-sm border border-border px-3 py-2 text-[13.5px] outline-none focus:border-teal-500"
            />
          </div>

          {error && (
            <p className="flex items-center gap-1.5 text-[12.5px] text-red-600">
              <TriangleAlert size={13} /> {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-1.5 rounded-sm bg-teal-500 py-2.5 text-[13.5px] font-medium text-white hover:bg-teal-600 disabled:opacity-60"
          >
            {loading ? <Loader2 size={14} className="animate-spin" /> : <LogIn size={14} />}
            Sign in
          </button>

          <button
            type="button"
            onClick={() => setError("Google Login needs OAuth credentials configured in .env — see README.")}
            className="w-full flex items-center justify-center gap-2 rounded-sm border border-border py-2.5 text-[13px] font-medium text-ink-soft hover:bg-fog"
          >
            <svg width="14" height="14" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.99.66-2.25 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A10.99 10.99 0 0012 23z"/><path fill="#FBBC05" d="M5.84 14.09A6.6 6.6 0 015.5 12c0-.73.13-1.43.34-2.09V7.07H2.18A11 11 0 001 12c0 1.77.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
          </button>

          <p className="text-center text-[12.5px] text-ink-muted pt-1">
            No account? <Link href="/register" className="text-teal-600 font-medium hover:underline">Create one</Link>
          </p>
        </form>

        <div className="mt-4 rounded-md border border-line bg-fog px-3.5 py-2.5">
          <p className="text-[11.5px] text-ink-faint">
            Demo admin: <span className="font-mono">admin@civiclens.ai</span> / <span className="font-mono">admin123</span>
          </p>
        </div>
      </div>
    </div>
  );
}
