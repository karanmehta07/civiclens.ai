"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { Loader2, UserPlus, TriangleAlert } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const { refresh } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error || "Something went wrong.");
      return;
    }
    await refresh();
    router.push("/");
  }

  return (
    <div className="min-h-[calc(100vh-90px)] md:min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="text-center mb-7">
          <h1 className="font-display font-bold text-[22px] tracking-tightest text-ink">Join CivicLens AI</h1>
          <p className="text-[13px] text-ink-muted mt-1">Report issues, earn points, help fix your city.</p>
        </div>

        <form onSubmit={submit} className="bg-surface border border-border rounded-lg p-5 space-y-3.5 shadow-subtle">
          <div>
            <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Full name</label>
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Karan Shah"
              className="w-full rounded-sm border border-border px-3 py-2 text-[13.5px] outline-none focus:border-teal-500"
            />
          </div>
          <div>
            <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-sm border border-border px-3 py-2 text-[13.5px] outline-none focus:border-teal-500"
            />
          </div>
          <div>
            <label className="block text-[12px] font-medium text-ink-soft mb-1.5">Password</label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="At least 6 characters"
              className="w-full rounded-sm border border-border px-3 py-2 text-[13.5px] outline-none focus:border-teal-500"
            />
          </div>

          {error && (
            <p className="flex items-center gap-1.5 text-[12.5px] text-red-600">
              <TriangleAlert size={13} /> {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-1.5 rounded-sm bg-teal-500 py-2.5 text-[13.5px] font-medium text-white hover:bg-teal-600 disabled:opacity-60"
          >
            {loading ? <Loader2 size={14} className="animate-spin" /> : <UserPlus size={14} />}
            Create account
          </button>

          <p className="text-center text-[12.5px] text-ink-muted pt-1">
            Already have an account? <Link href="/login" className="text-teal-600 font-medium hover:underline">Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
