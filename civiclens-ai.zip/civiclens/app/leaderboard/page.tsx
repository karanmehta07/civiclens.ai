"use client";

import { useEffect, useState } from "react";
import { Trophy, Medal, Award, Sparkles } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

interface Entry {
  id: string;
  name: string;
  points: number;
  reportsCount: number;
  badges: string[];
}

const BADGE_ICON: Record<string, { icon: React.ElementType; color: string }> = {
  "Civic Hero": { icon: Sparkles, color: "#0F7A72" },
  "Top Reporter": { icon: Award, color: "#DC8A15" },
  "Community Guardian": { icon: Medal, color: "#5B6470" },
  "Waste Warrior": { icon: Trophy, color: "#E5484D" },
};

const RANK_STYLE = ["bg-amber-300 text-ink", "bg-line text-ink-soft", "bg-amber-100 text-amber-600"];

export default function LeaderboardPage() {
  const { user } = useAuth();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/leaderboard")
      .then((r) => r.json())
      .then((d) => {
        setEntries(d.leaderboard || []);
        setLoading(false);
      });
  }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-6">
        <h1 className="font-display font-bold text-[22px] tracking-tightest text-ink flex items-center gap-2">
          <Trophy size={20} className="text-amber-500" /> Civic leaderboard
        </h1>
        <p className="text-[13px] text-ink-muted mt-1">
          Points for reporting, verifying, voting, and uploading evidence. Top contributors keep the city honest.
        </p>
      </div>

      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-16 skeleton rounded-md" />)}
        </div>
      ) : entries.length === 0 ? (
        <p className="text-[13px] text-ink-muted">No contributors yet — be the first to report an issue.</p>
      ) : (
        <div className="space-y-2">
          {entries.map((e, i) => (
            <div
              key={e.id}
              className={`flex items-center gap-3.5 rounded-md border p-3.5 transition-colors ${
                user?.id === e.id ? "border-teal-300 bg-teal-50" : "border-border bg-surface"
              }`}
            >
              <span
                className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[13px] font-mono font-semibold ${
                  RANK_STYLE[i] || "bg-fog text-ink-faint"
                }`}
              >
                {i + 1}
              </span>
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-teal-500 text-[13px] font-semibold text-white">
                {e.name.charAt(0).toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[13.5px] font-medium text-ink truncate">{e.name}</p>
                <p className="text-[11.5px] text-ink-faint">{e.reportsCount} reports filed</p>
              </div>
              <div className="hidden sm:flex items-center gap-1.5">
                {e.badges.map((b) => {
                  const meta = BADGE_ICON[b];
                  if (!meta) return null;
                  const Icon = meta.icon;
                  return (
                    <span
                      key={b}
                      title={b}
                      className="flex h-6 w-6 items-center justify-center rounded-full"
                      style={{ backgroundColor: `${meta.color}18` }}
                    >
                      <Icon size={12} style={{ color: meta.color }} />
                    </span>
                  );
                })}
              </div>
              <span className="font-mono text-[15px] font-semibold text-ink shrink-0">{e.points}<span className="text-[10px] text-ink-faint font-sans"> pt</span></span>
            </div>
          ))}
        </div>
      )}

      <div className="mt-8 grid sm:grid-cols-2 gap-3">
        {Object.entries(BADGE_ICON).map(([name, meta]) => {
          const Icon = meta.icon;
          return (
            <div key={name} className="flex items-center gap-2.5 rounded-md border border-line bg-fog p-3">
              <span className="flex h-8 w-8 items-center justify-center rounded-full" style={{ backgroundColor: `${meta.color}18` }}>
                <Icon size={14} style={{ color: meta.color }} />
              </span>
              <div>
                <p className="text-[12.5px] font-medium text-ink">{name}</p>
                <p className="text-[11px] text-ink-faint">
                  {name === "Civic Hero" && "Filed your first report"}
                  {name === "Top Reporter" && "Filed 5+ verified reports"}
                  {name === "Community Guardian" && "150+ contribution points"}
                  {name === "Waste Warrior" && "300+ contribution points"}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
