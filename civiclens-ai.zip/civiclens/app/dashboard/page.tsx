"use client";

import { useEffect, useState } from "react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  LineChart, Line, PieChart, Pie, Cell,
} from "recharts";
import { FileText, Activity, CheckCircle2, Clock } from "lucide-react";
import { CATEGORY_META } from "@/lib/utils";

interface Analytics {
  totals: { total: number; active: number; resolved: number; avgResolutionHours: number };
  byCategory: { category: string; label: string; count: number }[];
  byMonth: { month: string; count: number }[];
  statusCounts: { status: string; count: number }[];
  topAreas: { key: string; count: number; lat: number; lng: number }[];
  severityCounts: { severity: string; count: number }[];
}

const SEVERITY_COLORS: Record<string, string> = {
  low: "#5B6470",
  medium: "#F2A93B",
  high: "#EF8286",
  critical: "#E5484D",
};

export default function DashboardPage() {
  const [data, setData] = useState<Analytics | null>(null);

  useEffect(() => {
    fetch("/api/analytics").then((r) => r.json()).then(setData);
  }, []);

  if (!data) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-24 skeleton rounded-lg" />)}
        </div>
        <div className="h-72 skeleton rounded-lg" />
      </div>
    );
  }

  const cards = [
    { label: "Total Reports", value: data.totals.total, icon: FileText, color: "#0F7A72" },
    { label: "Active Issues", value: data.totals.active, icon: Activity, color: "#DC8A15" },
    { label: "Resolved Issues", value: data.totals.resolved, icon: CheckCircle2, color: "#0C6961" },
    { label: "Avg Resolution Time", value: `${data.totals.avgResolutionHours}h`, icon: Clock, color: "#5B6470" },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-6">
        <h1 className="font-display font-bold text-[22px] tracking-tightest text-ink">Analytics dashboard</h1>
        <p className="text-[13px] text-ink-muted mt-1">City-wide civic health, at a glance.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="bg-surface border border-border rounded-lg p-4">
              <div className="flex items-center gap-1.5 mb-2">
                <Icon size={14} style={{ color: c.color }} />
                <p className="text-[11.5px] font-medium text-ink-faint">{c.label}</p>
              </div>
              <p className="font-mono text-[26px] font-semibold text-ink tracking-tighter">{c.value}</p>
            </div>
          );
        })}
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-4">
        <div className="bg-surface border border-border rounded-lg p-5">
          <p className="text-[13px] font-semibold text-ink mb-4">Reports by category</p>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={data.byCategory} layout="vertical" margin={{ left: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EDEFF2" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11, fill: "#8A93A0" }} axisLine={false} tickLine={false} />
              <YAxis
                type="category"
                dataKey="label"
                width={110}
                tick={{ fontSize: 11, fill: "#5B6470" }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E3E7EC" }}
                cursor={{ fill: "#F5F6F8" }}
              />
              <Bar dataKey="count" fill="#0F7A72" radius={[0, 4, 4, 0]} barSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-surface border border-border rounded-lg p-5">
          <p className="text-[13px] font-semibold text-ink mb-4">Reports over time</p>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={data.byMonth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EDEFF2" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#8A93A0" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#8A93A0" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E3E7EC" }} />
              <Line type="monotone" dataKey="count" stroke="#0F7A72" strokeWidth={2.5} dot={{ r: 3, fill: "#0F7A72" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-surface border border-border rounded-lg p-5">
          <p className="text-[13px] font-semibold text-ink mb-4">Severity breakdown</p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={data.severityCounts} dataKey="count" nameKey="severity" innerRadius={45} outerRadius={72} paddingAngle={2}>
                {data.severityCounts.map((s) => (
                  <Cell key={s.severity} fill={SEVERITY_COLORS[s.severity]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #E3E7EC" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-2.5 justify-center mt-1">
            {data.severityCounts.map((s) => (
              <div key={s.severity} className="flex items-center gap-1.5 text-[11px] text-ink-muted capitalize">
                <span className="h-2 w-2 rounded-full" style={{ background: SEVERITY_COLORS[s.severity] }} /> {s.severity}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-5">
          <p className="text-[13px] font-semibold text-ink mb-4">Status pipeline</p>
          <div className="space-y-2.5">
            {data.statusCounts.map((s) => {
              const max = Math.max(...data.statusCounts.map((x) => x.count), 1);
              return (
                <div key={s.status}>
                  <div className="flex justify-between text-[11.5px] mb-1">
                    <span className="capitalize text-ink-muted">{s.status.replace("_", " ")}</span>
                    <span className="font-mono text-ink-soft">{s.count}</span>
                  </div>
                  <div className="h-1.5 w-full rounded-full bg-line overflow-hidden">
                    <div className="h-full bg-teal-500 rounded-full" style={{ width: `${(s.count / max) * 100}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-5">
          <p className="text-[13px] font-semibold text-ink mb-4">Top affected areas</p>
          <div className="space-y-2">
            {data.topAreas.map((a, i) => (
              <div key={a.key} className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-[12px] text-ink-soft">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-fog text-[10px] font-mono text-ink-faint">{i + 1}</span>
                  {a.lat.toFixed(2)}, {a.lng.toFixed(2)}
                </span>
                <span className="text-[11.5px] font-mono text-ink-faint">{a.count} reports</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
