import { NextRequest, NextResponse } from "next/server";
import { getDB, saveDB } from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ notifications: [] });
  const db = await getDB();
  const notifications = db.data.notifications
    .filter((n) => n.userId === user.sub)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 30);
  return NextResponse.json({ notifications });
}

export async function PATCH(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  const db = await getDB();
  for (const n of db.data.notifications) {
    if (n.userId === user.sub) n.read = true;
  }
  await saveDB(db);
  return NextResponse.json({ ok: true });
}
