import { NextRequest, NextResponse } from "next/server";
import { classifyWaste } from "@/lib/ai/wasteSorter";

export async function POST(req: NextRequest) {
  const form = await req.formData();
  const file = form.get("photo") as File | null;
  if (!file || file.size === 0) {
    return NextResponse.json({ error: "Please upload a photo of the item." }, { status: 400 });
  }
  if (file.size > 8 * 1024 * 1024) {
    return NextResponse.json({ error: "Image must be under 8MB." }, { status: 400 });
  }
  if (!file.type.startsWith("image/")) {
    return NextResponse.json({ error: "Uploaded file must be an image." }, { status: 400 });
  }
  const buffer = Buffer.from(await file.arrayBuffer());
  const result = await classifyWaste(buffer);
  return NextResponse.json({ result });
}
