import { NextRequest, NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { getDB, saveDB } from "@/lib/db";
import { hashPassword, signToken, AUTH_COOKIE } from "@/lib/auth";
import type { User } from "@/types";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { name, email, password } = body as { name: string; email: string; password: string };

  if (!name || !email || !password) {
    return NextResponse.json({ error: "Name, email, and password are required." }, { status: 400 });
  }
  if (password.length < 6) {
    return NextResponse.json({ error: "Password must be at least 6 characters." }, { status: 400 });
  }

  const db = await getDB();
  const exists = db.data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  if (exists) {
    return NextResponse.json({ error: "An account with this email already exists." }, { status: 409 });
  }

  const user: User = {
    id: nanoid(10),
    name,
    email,
    passwordHash: await hashPassword(password),
    role: "citizen",
    points: 0,
    badges: [],
    authProvider: "credentials",
    createdAt: new Date().toISOString(),
  };
  db.data.users.push(user);
  await saveDB(db);

  const token = signToken({ sub: user.id, name: user.name, email: user.email, role: user.role });
  const res = NextResponse.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role, points: user.points } });
  res.cookies.set(AUTH_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 7 });
  return res;
}
