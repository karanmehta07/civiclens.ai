import { NextResponse } from "next/server";
import { getDB } from "@/lib/db";
import { CATEGORY_META } from "@/lib/utils";

export async function GET() {
  const db = await getDB();
  const reports = db.data.reports.filter((r) => !r.spam);

  const total = reports.length;
  const resolved = reports.filter((r) => r.status === "resolved").length;
  const active = total - resolved;

  const resolutionTimes = reports
    .filter((r) => r.status === "resolved")
    .map((r) => {
      const reportedAt = new Date(r.statusHistory[0]?.at || r.createdAt).getTime();
      const resolvedAt = new Date(
        r.statusHistory.find((s) => s.status === "resolved")?.at || r.updatedAt
      ).getTime();
      return (resolvedAt - reportedAt) / (1000 * 60 * 60);
    });
  const avgResolutionHours = resolutionTimes.length
    ? resolutionTimes.reduce((a, b) => a + b, 0) / resolutionTimes.length
    : 0;

  const byCategory = Object.keys(CATEGORY_META).map((cat) => ({
    category: cat,
    label: CATEGORY_META[cat as keyof typeof CATEGORY_META].label,
    count: reports.filter((r) => r.category === cat).length,
  }));

  const monthMap = new Map<string, number>();
  for (const r of reports) {
    const d = new Date(r.createdAt);
    const key = `${d.toLocaleString("en-US", { month: "short" })} '${String(d.getFullYear()).slice(2)}`;
    monthMap.set(key, (monthMap.get(key) || 0) + 1);
  }
  const byMonth = Array.from(monthMap.entries()).map(([month, count]) => ({ month, count }));

  const statusCounts = ["reported", "verified", "assigned", "in_progress", "resolved"].map((s) => ({
    status: s,
    count: reports.filter((r) => r.status === s).length,
  }));

  // top affected areas: bucket by rounded lat/lng (~1.1km grid)
  const areaMap = new Map<string, { count: number; lat: number; lng: number }>();
  for (const r of reports) {
    const key = `${r.lat.toFixed(2)},${r.lng.toFixed(2)}`;
    const cur = areaMap.get(key) || { count: 0, lat: r.lat, lng: r.lng };
    cur.count += 1;
    areaMap.set(key, cur);
  }
  const topAreas = Array.from(areaMap.entries())
    .map(([key, v]) => ({ key, ...v }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);

  const severityCounts = ["low", "medium", "high", "critical"].map((s) => ({
    severity: s,
    count: reports.filter((r) => r.severity === s).length,
  }));

  return NextResponse.json({
    totals: { total, active, resolved, avgResolutionHours: Math.round(avgResolutionHours * 10) / 10 },
    byCategory,
    byMonth,
    statusCounts,
    topAreas,
    severityCounts,
  });
}
