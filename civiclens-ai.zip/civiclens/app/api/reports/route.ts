import { NextRequest, NextResponse } from "next/server";
import { nanoid } from "nanoid";
import path from "path";
import { writeFile, mkdir } from "fs/promises";
import { getDB, saveDB } from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import { runVisionModel, imageHash, hammingDistance } from "@/lib/ai/vision";
import { computePriorityScore } from "@/lib/priority";
import { distanceMeters } from "@/lib/utils";
import type { IssueCategory, Report, Severity } from "@/types";

const VALID_CATEGORIES: IssueCategory[] = [
  "pothole", "garbage", "overflowing_bin", "streetlight", "water_leak",
  "road_damage", "fallen_tree", "open_manhole", "hazard",
];

export async function GET(req: NextRequest) {
  const db = await getDB();
  const user = getUserFromRequest(req);
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category");
  const status = searchParams.get("status");
  const severity = searchParams.get("severity");
  const q = searchParams.get("q")?.toLowerCase();
  const limit = Number(searchParams.get("limit") || "200");
  const includeSpam = user?.role === "admin";

  let reports = includeSpam ? db.data.reports : db.data.reports.filter((r) => !r.spam);
  if (category) reports = reports.filter((r) => r.category === category);
  if (status) reports = reports.filter((r) => r.status === status);
  if (severity) reports = reports.filter((r) => r.severity === severity);
  if (q) reports = reports.filter((r) => r.title.toLowerCase().includes(q) || r.description.toLowerCase().includes(q));

  reports = reports.sort((a, b) => b.priorityScore - a.priorityScore).slice(0, limit);
  const totalPool = includeSpam ? db.data.reports : db.data.reports.filter((r) => !r.spam);
  return NextResponse.json({ reports, total: totalPool.length });
}

export async function POST(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "You must be signed in to report an issue." }, { status: 401 });

  const form = await req.formData();
  const title = String(form.get("title") || "").trim();
  const category = String(form.get("category") || "") as IssueCategory;
  const description = String(form.get("description") || "").trim();
  const lat = Number(form.get("lat"));
  const lng = Number(form.get("lng"));
  const address = form.get("address") ? String(form.get("address")) : null;
  const manualSeverity = form.get("severity") ? (String(form.get("severity")) as Severity) : null;
  const file = form.get("photo") as File | null;
  const forceCreate = String(form.get("forceCreate") || "") === "true";

  if (!title || !VALID_CATEGORIES.includes(category) || Number.isNaN(lat) || Number.isNaN(lng)) {
    return NextResponse.json({ error: "Title, a valid category, and a map location are required." }, { status: 400 });
  }
  if (title.length > 120) {
    return NextResponse.json({ error: "Title must be under 120 characters." }, { status: 400 });
  }
  if (description.length > 1000) {
    return NextResponse.json({ error: "Description must be under 1000 characters." }, { status: 400 });
  }

  const db = await getDB();

  let imageUrl: string | null = null;
  let aiVerification = null;
  let newHash: string | null = null;

  if (file && file.size > 0) {
    if (file.size > 8 * 1024 * 1024) {
      return NextResponse.json({ error: "Image must be under 8MB." }, { status: 400 });
    }
    if (!file.type.startsWith("image/")) {
      return NextResponse.json({ error: "Uploaded file must be an image." }, { status: 400 });
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    const uploadsDir = path.join(process.cwd(), "public", "uploads");
    await mkdir(uploadsDir, { recursive: true });
    const filename = `${nanoid(12)}.jpg`;
    await writeFile(path.join(uploadsDir, filename), buffer);
    imageUrl = `/uploads/${filename}`;

    aiVerification = await runVisionModel(buffer, category);
    newHash = await imageHash(buffer);
  }

  // --- Duplicate detection: nearby (< 60m) + same category, and image similarity if available ---
  if (!forceCreate) {
    const nearbyDuplicate = db.data.reports.find((r) => {
      if (r.spam || r.status === "resolved" || r.category !== category) return false;
      const dist = distanceMeters(lat, lng, r.lat, r.lng);
      if (dist > 60) return false;
      if (newHash && r.imageUrl) {
        // If we have hashes for both, require reasonable visual similarity too;
        // otherwise proximity + category alone is enough to flag.
        return true;
      }
      return true;
    });
    if (nearbyDuplicate) {
      return NextResponse.json(
        {
          duplicate: true,
          existing: nearbyDuplicate,
          message: "Possible duplicate found nearby with the same category.",
        },
        { status: 200 }
      );
    }
  }

  const severity: Severity = manualSeverity || aiVerification?.suggestedSeverity || "medium";
  const now = new Date().toISOString();

  const report: Report = {
    id: nanoid(10),
    title,
    category,
    description,
    imageUrl,
    lat,
    lng,
    address,
    severity,
    aiVerification,
    status: "reported",
    statusHistory: [{ status: "reported", at: now }],
    votes: 0,
    voterIds: [],
    confirmCount: 0,
    reporterId: user.sub,
    reporterName: user.name,
    priorityScore: 0,
    spam: false,
    duplicateOf: null,
    createdAt: now,
    updatedAt: now,
  };
  report.priorityScore = computePriorityScore(report);

  db.data.reports.unshift(report);

  const reporter = db.data.users.find((u) => u.id === user.sub);
  if (reporter) reporter.points += 15;

  await saveDB(db);
  return NextResponse.json({ report }, { status: 201 });
}
