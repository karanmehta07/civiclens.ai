import { NextRequest, NextResponse } from "next/server";
import { runVisionModel } from "@/lib/ai/vision";
import type { IssueCategory } from "@/types";

// Standalone AI verification preview: lets the report form show the model's
// confidence/severity estimate before the user submits, without persisting
// anything. The same runVisionModel() call runs again (deterministically)
// at submit time in /api/reports.
export async function POST(req: NextRequest) {
  const form = await req.formData();
  const file = form.get("photo") as File | null;
  const category = String(form.get("category") || "hazard") as IssueCategory;

  if (!file || file.size === 0) {
    return NextResponse.json({ error: "No photo provided." }, { status: 400 });
  }
  if (file.size > 8 * 1024 * 1024) {
    return NextResponse.json({ error: "Image must be under 8MB." }, { status: 400 });
  }
  const buffer = Buffer.from(await file.arrayBuffer());
  const aiVerification = await runVisionModel(buffer, category);
  return NextResponse.json({ aiVerification });
}
