import { NextRequest, NextResponse } from "next/server";
import { getDB, saveDB } from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import { nanoid } from "nanoid";
import type { IssueStatus } from "@/types";

const PIPELINE: IssueStatus[] = ["reported", "verified", "assigned", "in_progress", "resolved"];

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "admin") {
    return NextResponse.json({ error: "Only admins can update issue status." }, { status: 403 });
  }
  const { id } = await params;
  const { status, spam } = (await req.json()) as { status?: IssueStatus; spam?: boolean };

  const db = await getDB();
  const report = db.data.reports.find((r) => r.id === id);
  if (!report) return NextResponse.json({ error: "Report not found." }, { status: 404 });

  if (typeof spam === "boolean") {
    report.spam = spam;
    report.updatedAt = new Date().toISOString();
    await saveDB(db);
    return NextResponse.json({ report });
  }

  if (!status || !PIPELINE.includes(status)) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }

  report.status = status;
  report.statusHistory.push({ status, at: new Date().toISOString() });
  report.updatedAt = new Date().toISOString();

  if (status === "verified" || status === "resolved") {
    db.data.notifications.unshift({
      id: nanoid(10),
      userId: report.reporterId,
      type: status === "resolved" ? "resolved" : "verified",
      message:
        status === "resolved"
          ? `Great news — your report "${report.title}" has been marked resolved.`
          : `Your report "${report.title}" was verified by the municipal team.`,
      reportId: report.id,
      read: false,
      createdAt: new Date().toISOString(),
    });
    const reporter = db.data.users.find((u) => u.id === report.reporterId);
    if (reporter) reporter.points += status === "resolved" ? 20 : 10;
  }

  await saveDB(db);
  return NextResponse.json({ report });
}
