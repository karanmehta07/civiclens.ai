import { NextRequest, NextResponse } from "next/server";
import { getDB, saveDB } from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import { computePriorityScore } from "@/lib/priority";
import { nanoid } from "nanoid";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Sign in to vote on issues." }, { status: 401 });
  const { id } = await params;
  const { confirm } = (await req.json().catch(() => ({}))) as { confirm?: boolean };

  const db = await getDB();
  const report = db.data.reports.find((r) => r.id === id);
  if (!report) return NextResponse.json({ error: "Report not found." }, { status: 404 });

  if (report.voterIds.includes(user.sub)) {
    return NextResponse.json({ error: "You've already voted on this report." }, { status: 409 });
  }

  report.votes += 1;
  report.voterIds.push(user.sub);
  if (confirm) report.confirmCount += 1;
  report.priorityScore = computePriorityScore(report);
  report.updatedAt = new Date().toISOString();

  const voter = db.data.users.find((u) => u.id === user.sub);
  if (voter) voter.points += 3;

  // vote milestone notification for the reporter
  if ([5, 10, 25, 50].includes(report.votes)) {
    db.data.notifications.unshift({
      id: nanoid(10),
      userId: report.reporterId,
      type: "vote_milestone",
      message: `Your report "${report.title}" just reached ${report.votes} votes.`,
      reportId: report.id,
      read: false,
      createdAt: new Date().toISOString(),
    });
  }

  await saveDB(db);
  return NextResponse.json({ report });
}
