import { NextRequest, NextResponse } from "next/server";
import { getDB, saveDB } from "@/lib/db";
import { getUserFromRequest } from "@/lib/auth";
import { nanoid } from "nanoid";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Sign in to comment." }, { status: 401 });
  const { id } = await params;
  const { text } = (await req.json()) as { text: string };
  if (!text || !text.trim()) return NextResponse.json({ error: "Comment cannot be empty." }, { status: 400 });
  if (text.length > 500) return NextResponse.json({ error: "Comment must be under 500 characters." }, { status: 400 });

  const db = await getDB();
  const report = db.data.reports.find((r) => r.id === id);
  if (!report) return NextResponse.json({ error: "Report not found." }, { status: 404 });

  const comment = {
    id: nanoid(10),
    reportId: id,
    userId: user.sub,
    userName: user.name,
    text: text.trim(),
    createdAt: new Date().toISOString(),
  };
  db.data.comments.push(comment);

  if (report.reporterId !== user.sub) {
    db.data.notifications.unshift({
      id: nanoid(10),
      userId: report.reporterId,
      type: "comment",
      message: `${user.name} commented on your report "${report.title}".`,
      reportId: report.id,
      read: false,
      createdAt: new Date().toISOString(),
    });
  }

  const commenter = db.data.users.find((u) => u.id === user.sub);
  if (commenter) commenter.points += 2;

  await saveDB(db);
  return NextResponse.json({ comment }, { status: 201 });
}
