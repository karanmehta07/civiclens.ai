import { NextRequest, NextResponse } from "next/server";
import { getDB } from "@/lib/db";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const db = await getDB();
  const report = db.data.reports.find((r) => r.id === id);
  if (!report) return NextResponse.json({ error: "Report not found." }, { status: 404 });
  const comments = db.data.comments.filter((c) => c.reportId === id).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  return NextResponse.json({ report, comments });
}
