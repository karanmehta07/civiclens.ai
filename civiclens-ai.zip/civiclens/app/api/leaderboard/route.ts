import { NextResponse } from "next/server";
import { getDB } from "@/lib/db";

function badgesFor(points: number, reportsCount: number): string[] {
  const badges: string[] = [];
  if (reportsCount >= 1) badges.push("Civic Hero");
  if (reportsCount >= 5) badges.push("Top Reporter");
  if (points >= 150) badges.push("Community Guardian");
  if (points >= 300) badges.push("Waste Warrior");
  return badges;
}

export async function GET() {
  const db = await getDB();
  const counts = new Map<string, number>();
  for (const r of db.data.reports) counts.set(r.reporterId, (counts.get(r.reporterId) || 0) + 1);

  const board = db.data.users
    .filter((u) => u.role === "citizen")
    .map((u) => ({
      id: u.id,
      name: u.name,
      points: u.points,
      reportsCount: counts.get(u.id) || 0,
      badges: badgesFor(u.points, counts.get(u.id) || 0),
    }))
    .sort((a, b) => b.points - a.points)
    .slice(0, 25);

  return NextResponse.json({ leaderboard: board });
}
