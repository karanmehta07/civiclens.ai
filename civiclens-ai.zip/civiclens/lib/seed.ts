import { getDB, saveDB } from "./db";
import { hashPassword } from "./auth";
import { nanoid } from "nanoid";
import { computePriorityScore } from "./priority";
import type { IssueCategory, Report, Severity, User } from "@/types";

const CENTER = { lat: 23.0225, lng: 72.5714 }; // Ahmedabad

function jitter(base: number, spread: number) {
  return base + (Math.random() - 0.5) * spread;
}

const CATEGORIES: IssueCategory[] = [
  "pothole",
  "garbage",
  "overflowing_bin",
  "streetlight",
  "water_leak",
  "road_damage",
  "fallen_tree",
  "open_manhole",
  "hazard",
];
const SEVERITIES: Severity[] = ["low", "medium", "high", "critical"];

const TITLES: Record<IssueCategory, string[]> = {
  pothole: ["Deep pothole near junction", "Multiple potholes on service road", "Pothole causing traffic slowdown"],
  garbage: ["Illegal garbage dump on roadside", "Construction debris left on street", "Unattended waste pile"],
  overflowing_bin: ["Community bin overflowing for days", "Bin overflow attracting stray animals"],
  streetlight: ["Streetlight out for a week", "Flickering pole light, safety risk", "Dark stretch, no working light"],
  water_leak: ["Pipeline leak flooding footpath", "Continuous water seepage from main"],
  road_damage: ["Cracked pavement, tripping hazard", "Road edge collapsed after rain"],
  fallen_tree: ["Tree fallen after storm blocking lane", "Branch down on footpath"],
  open_manhole: ["Manhole cover missing, fall risk", "Open drain cover near school"],
  hazard: ["Exposed wiring near bus stop", "Debris blocking pedestrian crossing"],
};

async function main() {
  const db = await getDB();

  const users: User[] = [
    {
      id: "admin-1",
      name: "Municipal Admin",
      email: "admin@civiclens.ai",
      passwordHash: await hashPassword("admin123"),
      role: "admin",
      points: 0,
      badges: [],
      authProvider: "credentials",
      createdAt: new Date().toISOString(),
    },
  ];

  const citizenNames = [
    "Aarav Patel", "Diya Shah", "Kabir Mehta", "Ishita Joshi", "Rohan Desai",
    "Ananya Trivedi", "Vivaan Rao", "Myra Iyer", "Aditya Nair", "Sara Khan",
  ];
  for (let i = 0; i < citizenNames.length; i++) {
    users.push({
      id: `user-${i + 1}`,
      name: citizenNames[i],
      email: `${citizenNames[i].split(" ")[0].toLowerCase()}@example.com`,
      passwordHash: await hashPassword("password123"),
      role: "citizen",
      points: Math.floor(Math.random() * 400),
      badges: [],
      authProvider: "credentials",
      createdAt: new Date().toISOString(),
    });
  }

  const reports: Report[] = [];
  for (let i = 0; i < 42; i++) {
    const category = CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)];
    const severity = SEVERITIES[Math.floor(Math.random() * SEVERITIES.length)];
    const votes = Math.floor(Math.random() * 60);
    const daysAgo = Math.floor(Math.random() * 30);
    const createdAt = new Date(Date.now() - daysAgo * 86400000).toISOString();
    const statuses: Report["status"][] = ["reported", "verified", "assigned", "in_progress", "resolved"];
    const status = statuses[Math.min(statuses.length - 1, Math.floor(Math.random() * (daysAgo > 15 ? 5 : 3)))];
    const titles = TITLES[category];
    const reporter = users[Math.floor(Math.random() * users.length)];

    const report: Report = {
      id: nanoid(10),
      title: titles[Math.floor(Math.random() * titles.length)],
      category,
      description:
        "Reported via CivicLens AI mobile capture. Please verify and prioritize based on community impact.",
      imageUrl: null,
      lat: jitter(CENTER.lat, 0.09),
      lng: jitter(CENTER.lng, 0.09),
      address: "Ahmedabad, Gujarat",
      severity,
      aiVerification: {
        detectedCategory: category,
        confidence: Math.round((0.7 + Math.random() * 0.28) * 100) / 100,
        suggestedSeverity: severity,
        labels: ["seed-data"],
        reasoning: "Synthetic seed record for demo purposes.",
        model: "civiclens-heuristic-vision-v1",
      },
      status,
      statusHistory: [{ status: "reported", at: createdAt }],
      votes,
      voterIds: [],
      confirmCount: Math.floor(votes / 3),
      reporterId: reporter.id,
      reporterName: reporter.name,
      priorityScore: 0,
      spam: false,
      duplicateOf: null,
      createdAt,
      updatedAt: createdAt,
    };
    report.priorityScore = computePriorityScore(report);
    reports.push(report);
  }

  db.data = { users, reports, comments: [], notifications: [] };
  await saveDB(db);
  console.log(`Seeded ${users.length} users and ${reports.length} reports.`);
  console.log("Admin login: admin@civiclens.ai / admin123");
  console.log("Citizen login: aarav@example.com / password123 (any seeded citizen, same password)");
}

main().then(() => process.exit(0));
