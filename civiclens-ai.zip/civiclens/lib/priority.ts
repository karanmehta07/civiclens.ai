import type { IssueCategory, Report, Severity } from "@/types";

const SEVERITY_WEIGHT: Record<Severity, number> = {
  low: 10,
  medium: 30,
  high: 55,
  critical: 80,
};

// Categories that pose direct physical danger get an extra hazard weight,
// distinct from severity (e.g. an open manhole is dangerous even at
// "medium" severity because of what it is, not just how it looks).
const HAZARD_WEIGHT: Record<IssueCategory, number> = {
  open_manhole: 25,
  water_leak: 10,
  fallen_tree: 15,
  streetlight: 8,
  pothole: 12,
  road_damage: 12,
  hazard: 20,
  garbage: 4,
  overflowing_bin: 4,
};

/**
 * Priority = AI Severity + Vote Count + Report Age + Hazard Weight
 *
 * - AI Severity: mapped weight of the (AI-suggested or user-confirmed) severity
 * - Vote Count: each community vote/confirmation adds weight, diminishing
 *   returns after the first ~20 votes so brigading can't dominate the score
 * - Report Age: older *unresolved* reports gently climb in priority so they
 *   don't get buried by newer reports
 * - Hazard Weight: fixed weight per category reflecting inherent danger
 */
export function computePriorityScore(report: Pick<Report, "severity" | "votes" | "confirmCount" | "category" | "createdAt" | "status">): number {
  const severityScore = SEVERITY_WEIGHT[report.severity];
  const voteScore = Math.min(30, Math.sqrt(report.votes + report.confirmCount * 1.5) * 6);
  const ageDays = (Date.now() - new Date(report.createdAt).getTime()) / (1000 * 60 * 60 * 24);
  const ageScore = report.status === "resolved" ? 0 : Math.min(20, ageDays * 1.2);
  const hazardScore = HAZARD_WEIGHT[report.category] ?? 5;

  const total = severityScore + voteScore + ageScore + hazardScore;
  return Math.round(total * 10) / 10;
}

export function priorityTier(score: number): "Critical" | "High" | "Medium" | "Low" {
  if (score >= 90) return "Critical";
  if (score >= 60) return "High";
  if (score >= 35) return "Medium";
  return "Low";
}
