import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";
import path from "path";
import type { DB } from "@/types";

// ---------------------------------------------------------------------------
// Storage layer
//
// This uses lowdb (a JSON file) so the whole app runs with zero external
// services. The document shapes in /types mirror what the Mongoose schemas
// below would produce, so swapping this file for a real MongoDB connection
// is a drop-in change — every API route only ever calls getDB()/saveDB().
//
// --- Swap-in point for real MongoDB ---
// import mongoose from "mongoose";
// await mongoose.connect(process.env.MONGODB_URI!);
// Then replace getDB()/saveDB() calls with the Mongoose models defined in
// /lib/schemas (see comments at the bottom of this file for the schema).
// ---------------------------------------------------------------------------

const file = path.join(process.cwd(), "data", "db.json");
const defaultData: DB = { users: [], reports: [], comments: [], notifications: [] };

let _db: Low<DB> | null = null;

export async function getDB(): Promise<Low<DB>> {
  if (_db) {
    await _db.read();
    return _db;
  }
  const adapter = new JSONFile<DB>(file);
  const db = new Low<DB>(adapter, defaultData);
  await db.read();
  if (!db.data) {
    db.data = defaultData;
    await db.write();
  }
  _db = db;
  return db;
}

export async function saveDB(db: Low<DB>) {
  await db.write();
}

/* ---------------------------------------------------------------------------
MongoDB / Mongoose schema equivalents (for production swap-in):

const ReportSchema = new Schema({
  title: String,
  category: { type: String, enum: [...], index: true },
  description: String,
  imageUrl: String,
  location: { type: { type: String, default: "Point" }, coordinates: [Number] },
  severity: { type: String, enum: ["low","medium","high","critical"], index: true },
  aiVerification: { detectedCategory: String, confidence: Number, suggestedSeverity: String, labels: [String] },
  status: { type: String, enum: [...], default: "reported", index: true },
  statusHistory: [{ status: String, at: Date }],
  votes: { type: Number, default: 0, index: true },
  voterIds: [{ type: Schema.Types.ObjectId }],
  reporterId: { type: Schema.Types.ObjectId, ref: "User", index: true },
  priorityScore: { type: Number, index: true },
  spam: { type: Boolean, default: false },
  duplicateOf: { type: Schema.Types.ObjectId, ref: "Report", default: null },
}, { timestamps: true });
ReportSchema.index({ location: "2dsphere" });
ReportSchema.index({ status: 1, category: 1, createdAt: -1 });

const UserSchema = new Schema({
  name: String,
  email: { type: String, unique: true, index: true },
  passwordHash: String,
  role: { type: String, enum: ["citizen","admin"], default: "citizen" },
  points: { type: Number, default: 0, index: true },
  badges: [String],
}, { timestamps: true });

const CommentSchema = new Schema({
  reportId: { type: Schema.Types.ObjectId, ref: "Report", index: true },
  userId: { type: Schema.Types.ObjectId, ref: "User" },
  text: String,
}, { timestamps: true });

const NotificationSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: "User", index: true },
  type: String,
  message: String,
  reportId: { type: Schema.Types.ObjectId, ref: "Report" },
  read: { type: Boolean, default: false },
}, { timestamps: true });
--------------------------------------------------------------------------- */
