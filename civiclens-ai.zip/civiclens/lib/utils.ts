import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { IssueCategory, IssueStatus, Severity } from "@/types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Haversine distance in meters
export function distanceMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export const CATEGORY_META: Record<IssueCategory, { label: string; icon: string; color: string }> = {
  pothole: { label: "Pothole", icon: "circle-dashed", color: "#DC8A15" },
  garbage: { label: "Garbage Dump", icon: "trash-2", color: "#5B6470" },
  overflowing_bin: { label: "Overflowing Bin", icon: "archive-x", color: "#B36F0F" },
  streetlight: { label: "Broken Streetlight", icon: "lightbulb-off", color: "#0F7A72" },
  water_leak: { label: "Water Leak", icon: "droplets", color: "#0C6961" },
  road_damage: { label: "Road Damage", icon: "construction", color: "#DC8A15" },
  fallen_tree: { label: "Fallen Tree", icon: "tree-deciduous", color: "#5B6470" },
  open_manhole: { label: "Open Manhole", icon: "octagon-alert", color: "#E5484D" },
  hazard: { label: "Public Hazard", icon: "triangle-alert", color: "#E5484D" },
};

export const SEVERITY_META: Record<Severity, { label: string; color: string; bg: string }> = {
  low: { label: "Low", color: "#5B6470", bg: "#EDEFF2" },
  medium: { label: "Medium", color: "#B36F0F", bg: "#FBE4BC" },
  high: { label: "High", color: "#C53338", bg: "#FCEAEB" },
  critical: { label: "Critical", color: "#FFFFFF", bg: "#E5484D" },
};

export const STATUS_META: Record<IssueStatus, { label: string; order: number }> = {
  reported: { label: "Reported", order: 0 },
  verified: { label: "Verified", order: 1 },
  assigned: { label: "Assigned", order: 2 },
  in_progress: { label: "In Progress", order: 3 },
  resolved: { label: "Resolved", order: 4 },
};

export const STATUS_PIPELINE: IssueStatus[] = [
  "reported",
  "verified",
  "assigned",
  "in_progress",
  "resolved",
];

export function timeAgo(iso: string): string {
  const seconds = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  const units: [number, string][] = [
    [31536000, "y"],
    [2592000, "mo"],
    [86400, "d"],
    [3600, "h"],
    [60, "m"],
  ];
  for (const [secs, label] of units) {
    const v = Math.floor(seconds / secs);
    if (v >= 1) return `${v}${label} ago`;
  }
  return "just now";
}

export function formatCoord(n: number): string {
  return n.toFixed(5);
}
