import sharp from "sharp";

export type WasteType = "plastic" | "metal" | "glass" | "paper" | "organic";

export interface WasteResult {
  type: WasteType;
  confidence: number;
  recyclable: boolean;
  disposal: string;
  reasoning: string;
}

const DISPOSAL: Record<WasteType, { recyclable: boolean; text: string }> = {
  plastic: {
    recyclable: true,
    text: "Rinse and place in the blue recyclables bin. Flatten bottles to save space.",
  },
  metal: {
    recyclable: true,
    text: "Place in the metal/recyclables bin. Sharp edges should be wrapped before disposal.",
  },
  glass: {
    recyclable: true,
    text: "Place in the glass collection point. Do not mix with ceramics or mirrors.",
  },
  paper: {
    recyclable: true,
    text: "Keep dry and place in the paper recycling bin. Remove plastic tape or lamination first.",
  },
  organic: {
    recyclable: false,
    text: "Place in the green organic-waste bin for composting. Not suitable for recycling streams.",
  },
};

/**
 * Heuristic material classifier based on color, reflectance/specular
 * highlights (metal & glass tend to have bright, high-contrast highlights),
 * saturation (organics trend toward browns/greens, paper toward low
 * saturation near-white/tan), and texture uniformity.
 *
 * --- Swap-in point for a real model ---
 * Replace this function body with a call to a trained waste-classification
 * model (e.g. a Roboflow "trash-classification" endpoint or a TF.js model
 * loaded from /models). Keep the WasteResult return shape the same.
 */
export async function classifyWaste(buffer: Buffer): Promise<WasteResult> {
  const { data, info } = await sharp(buffer)
    .resize(96, 96, { fit: "cover" })
    .removeAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const n = info.width * info.height;
  let sumR = 0,
    sumG = 0,
    sumB = 0,
    highlightPx = 0,
    lowSatPx = 0;
  const lums: number[] = [];

  for (let i = 0; i < data.length; i += 3) {
    const r = data[i],
      g = data[i + 1],
      b = data[i + 2];
    sumR += r;
    sumG += g;
    sumB += b;
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    lums.push(lum);
    if (lum > 235) highlightPx++;
    const max = Math.max(r, g, b),
      min = Math.min(r, g, b);
    const sat = max === 0 ? 0 : (max - min) / max;
    if (sat < 0.12) lowSatPx++;
  }

  const avgR = sumR / n,
    avgG = sumG / n,
    avgB = sumB / n;
  const avgLum = lums.reduce((a, b) => a + b, 0) / n;
  const variance = lums.reduce((a, l) => a + (l - avgLum) ** 2, 0) / n;
  const specularRatio = highlightPx / n; // bright hotspots -> reflective material
  const lowSatRatio = lowSatPx / n;
  const greenness = avgG - Math.max(avgR, avgB);
  const brownness = avgR > avgG && avgG > avgB && avgR - avgB < 90 && avgLum < 150;

  const scores: Record<WasteType, number> = {
    plastic: 0.2,
    metal: 0.15,
    glass: 0.15,
    paper: 0.2,
    organic: 0.15,
  };

  // Reflective, high-contrast, low-saturation -> metal
  scores.metal += specularRatio * 2.2 + (variance > 3500 ? 0.15 : 0);
  // Reflective + higher saturation / transparency proxy (edge halo) -> glass
  scores.glass += specularRatio * 1.4 + (avgLum > 150 && lowSatRatio < 0.4 ? 0.1 : 0);
  // Very low saturation, mid-high brightness, low specular -> paper
  scores.paper += lowSatRatio * 0.9 + (avgLum > 140 && specularRatio < 0.05 ? 0.15 : 0);
  // Green/brown dominant, low brightness, low specular -> organic
  scores.organic += Math.max(0, greenness) / 60 + (brownness ? 0.35 : 0);
  // Saturated, colorful, low specular, moderate brightness -> plastic (default catch-all)
  scores.plastic += (1 - lowSatRatio) * 0.5 + (specularRatio < 0.08 ? 0.1 : 0);

  const entries = Object.entries(scores) as [WasteType, number][];
  entries.sort((a, b) => b[1] - a[1]);
  const [topType, topScore] = entries[0];
  const total = entries.reduce((a, [, s]) => a + Math.max(0, s), 0);
  const confidence = Math.max(0.4, Math.min(0.97, topScore / Math.max(total, 0.001)));

  const disposal = DISPOSAL[topType];
  return {
    type: topType,
    confidence: Math.round(confidence * 100) / 100,
    recyclable: disposal.recyclable,
    disposal: disposal.text,
    reasoning: `specular ${(specularRatio * 100).toFixed(0)}%, low-saturation ${(lowSatRatio * 100).toFixed(
      0
    )}%, avg RGB (${avgR.toFixed(0)}, ${avgG.toFixed(0)}, ${avgB.toFixed(0)}) → best match ${topType}.`,
  };
}
