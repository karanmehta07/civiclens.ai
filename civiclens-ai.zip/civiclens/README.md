# CivicLens AI

A crowdsourced civic-intelligence platform: citizens tap a map to report potholes, garbage dumps, broken streetlights, water leaks, and other public infrastructure issues. Photos are run through an AI verification model, the community votes and confirms reports, and a priority engine surfaces what the city should fix first.

This is a **fully working, runnable build** — not a mockup. Every feature in the spec works end-to-end on your machine with zero external accounts required. A few pieces that need real credentials (MongoDB Atlas, Cloudinary, Google OAuth, a trained YOLOv8 model) are implemented with honest, functioning stand-ins and a clearly marked swap-in point — see **"Going to production"** below.

## Quick start

```bash
npm install
cp .env.example .env      # already done for you; edit JWT_SECRET before deploying
npm run seed               # generates 11 demo users + 42 sample reports around Ahmedabad
npm run dev
```

Open **http://localhost:3000**.

**Demo logins**
| Role | Email | Password |
|---|---|---|
| Admin | `admin@civiclens.ai` | `admin123` |
| Citizen | `aarav@example.com` (or any seeded name, lowercased first name) | `password123` |

Or just click **Get started** and register a new account — full signup flow works.

## What's real vs. what's a stand-in

| Feature | This build | Production swap-in |
|---|---|---|
| Database | `lowdb` — a JSON file at `data/db.json`, same document shapes as the Mongoose schemas | Point `lib/db.ts` at MongoDB Atlas; schema reference is commented at the bottom of that file |
| AI photo verification | **Real image analysis** — `lib/ai/vision.ts` decodes the photo with `sharp` and computes edge density, contrast, and brightness to produce a genuine confidence score + severity estimate, not a random number | Swap the body of `runVisionModel()` for a call to your YOLOv8/Roboflow endpoint — the return shape already matches |
| Smart Waste Sorter | **Real image analysis** — `lib/ai/wasteSorter.ts` classifies material by color/reflectance signals | Swap `classifyWaste()` for a trained waste-classification model |
| Duplicate detection | Real: geo-proximity (Haversine, <60m) + category match + perceptual image hashing (aHash) | Already production-ready |
| Image storage | Local disk, `public/uploads/` | Swap the `writeFile` call in `app/api/reports/route.ts` for a Cloudinary upload |
| Auth (email/password) | **Real** — bcrypt + JWT in an httpOnly cookie | Already production-ready |
| Google Login | UI is wired up; button explains it needs your OAuth credentials | Add `GOOGLE_CLIENT_ID`/`SECRET` and wire NextAuth's Google provider |
| Real-time updates | 15–20s polling (see `HomeClient.tsx`, `NotificationBell.tsx`) | Swap for Socket.io — the data shapes are already what a socket payload would carry |
| Everything else | Fully real: map, report flow, voting, priority engine, status pipeline, heatmap, analytics, leaderboard, comments, notifications, admin console, spam moderation | — |

## Tech stack

- **Next.js 15** (App Router) + React 18 + TypeScript
- **Tailwind CSS** — custom civic design system (see `tailwind.config.ts`)
- **react-leaflet** + OpenStreetMap tiles + `leaflet.heat` for the hotspot heatmap
- **Recharts** for the analytics dashboard
- **sharp** for real image analysis (AI verification + waste sorter)
- **jsonwebtoken** + **bcryptjs** for auth
- **lowdb** as the zero-config database layer

## Project structure

```
app/
  page.tsx                 Homepage (map)
  dashboard/                Analytics dashboard
  leaderboard/               Civic leaderboard
  waste-sorter/               Smart Waste Sorter
  issue/[id]/                 Issue detail page
  admin/                       Admin console
  login/, register/
  api/
    reports/                  List, create, analyze
    reports/[id]/               vote, status, comments
    auth/                       login, register, logout, me
    leaderboard/, analytics/, waste-sort/, notifications/
components/                 All UI components
lib/
  ai/vision.ts                Report photo AI verification (real heuristic model)
  ai/wasteSorter.ts            Waste material classifier (real heuristic model)
  priority.ts                  Smart Priority Engine
  db.ts                        Storage layer (lowdb, Mongoose schema reference included)
  auth.ts                      JWT + password hashing
  seed.ts                      Demo data generator
types/index.ts               Shared types / schema shapes
```

## Smart Priority Engine

```
Priority = AI Severity + Vote Count (diminishing returns) + Report Age (unresolved only) + Hazard Weight (per category)
```

Implemented in `lib/priority.ts`, recomputed on every vote and status change. Tiers: Critical (90+), High (60+), Medium (35+), Low.

## Deployment

- **Frontend + API routes**: deploy as one Next.js app to Vercel (`vercel deploy`). Note the local-disk image storage and JSON-file database won't persist across Vercel's serverless invocations — swap those two pieces first (Cloudinary + MongoDB, both drop-in per the table above).
- **Render**: if you split the backend out, the API route logic in `app/api/**` maps 1:1 onto Express handlers if you'd rather run a standalone Node/Express server — the business logic in `lib/` is framework-agnostic and reusable as-is.

## Notes

- Rate limiting, input validation (title/description length, file size/type, password length), and spam moderation are implemented in the API routes.
- All uploaded images are capped at 8MB and validated as image MIME types before being written to disk.
- The heuristic AI models are real, fast, and dependency-free — good enough for a hackathon demo or investor walkthrough, and each has a one-function swap-in point when you're ready to wire up a trained model.
