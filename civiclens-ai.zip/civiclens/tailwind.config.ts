import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        fog: "#F5F6F8",
        surface: "#FFFFFF",
        ink: {
          DEFAULT: "#12181F",
          soft: "#2B333D",
          muted: "#5B6470",
          faint: "#8A93A0",
        },
        border: "#E3E7EC",
        line: "#EDEFF2",
        teal: {
          50: "#EAF6F4",
          100: "#CFEAE6",
          300: "#5FB6AC",
          500: "#0F7A72",
          600: "#0C6961",
          700: "#0A544E",
        },
        amber: {
          50: "#FDF3E3",
          100: "#FBE4BC",
          300: "#F2A93B",
          500: "#DC8A15",
          600: "#B36F0F",
        },
        red: {
          50: "#FCEAEB",
          300: "#EF8286",
          500: "#E5484D",
          600: "#C53338",
        },
      },
      fontFamily: {
        display: [
          "Helvetica Neue",
          "Arial Narrow",
          "Arial",
          "sans-serif",
        ],
        body: [
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
        mono: [
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "Consolas",
          "monospace",
        ],
      },
      borderRadius: {
        xs: "6px",
        sm: "8px",
        md: "12px",
        lg: "16px",
        xl: "22px",
      },
      boxShadow: {
        subtle: "0 1px 2px rgba(18,24,31,0.04), 0 1px 1px rgba(18,24,31,0.03)",
        card: "0 1px 3px rgba(18,24,31,0.06), 0 8px 24px -12px rgba(18,24,31,0.10)",
        pop: "0 12px 32px -8px rgba(18,24,31,0.18)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pulse-ring": {
          "0%": { transform: "scale(0.9)", opacity: "0.9" },
          "80%": { transform: "scale(2.1)", opacity: "0" },
          "100%": { opacity: "0" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-400px 0" },
          "100%": { backgroundPosition: "400px 0" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.5s cubic-bezier(.16,1,.3,1) both",
        "pulse-ring": "pulse-ring 1.8s cubic-bezier(0,0,0.2,1) infinite",
        shimmer: "shimmer 1.6s linear infinite",
      },
      letterSpacing: {
        tightest: "-0.04em",
        tighter: "-0.02em",
        wide: "0.06em",
        widest: "0.14em",
      },
    },
  },
  plugins: [],
};
export default config;
